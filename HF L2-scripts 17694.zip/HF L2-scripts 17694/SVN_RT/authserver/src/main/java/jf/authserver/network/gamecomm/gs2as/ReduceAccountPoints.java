package jf.authserver.network.gamecomm.gs2as;

import jf.authserver.accounts.Account;
import jf.authserver.network.gamecomm.ReceivablePacket;

public class ReduceAccountPoints extends ReceivablePacket
{
	private String account;
	private int count;

	@Override
	protected void readImpl()
	{
		account = readS();
		count = readD();
	}

	@Override
	protected void runImpl()
	{
		Account.reducePoints(account, count);
	}
}
