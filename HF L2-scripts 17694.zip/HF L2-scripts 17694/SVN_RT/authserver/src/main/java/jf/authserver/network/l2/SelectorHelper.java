package jf.authserver.network.l2;

import java.nio.channels.SocketChannel;

import jf.authserver.Config;
import jf.authserver.IpBanManager;
import jf.authserver.ThreadPoolManager;
import jf.authserver.network.l2.s2c.Init;
import jf.commons.net.nio.impl.IAcceptFilter;
import jf.commons.net.nio.impl.IClientFactory;
import jf.commons.net.nio.impl.IMMOExecutor;
import jf.commons.net.nio.impl.MMOConnection;
import jf.commons.threading.RunnableImpl;


public class SelectorHelper implements IMMOExecutor<L2LoginClient>, IClientFactory<L2LoginClient>, IAcceptFilter
{
	@Override
	public void execute(Runnable r)
	{
		ThreadPoolManager.getInstance().execute(r);
	}

	@Override
	public L2LoginClient create(MMOConnection<L2LoginClient> con)
	{
		final L2LoginClient client = new L2LoginClient(con);
		client.sendPacket(new Init(client));
		ThreadPoolManager.getInstance().schedule(() ->
		{
			client.closeNow(false);
		}, Config.LOGIN_TIMEOUT);
		return client;
	}

	@Override
	public boolean accept(SocketChannel sc)
	{
		return !IpBanManager.getInstance().isIpBanned(sc.socket().getInetAddress().getHostAddress());
	}
}