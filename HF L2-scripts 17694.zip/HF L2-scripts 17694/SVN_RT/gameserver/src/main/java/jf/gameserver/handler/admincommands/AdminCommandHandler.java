package jf.gameserver.handler.admincommands;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

import jf.commons.data.xml.AbstractHolder;
import jf.gameserver.handler.admincommands.impl.AdminAdmin;
import jf.gameserver.handler.admincommands.impl.AdminAnnouncements;
import jf.gameserver.handler.admincommands.impl.AdminAttribute;
import jf.gameserver.handler.admincommands.impl.AdminBan;
import jf.gameserver.handler.admincommands.impl.AdminCamera;
import jf.gameserver.handler.admincommands.impl.AdminCancel;
import jf.gameserver.handler.admincommands.impl.AdminChangeAccessLevel;
import jf.gameserver.handler.admincommands.impl.AdminCheckBot;
import jf.gameserver.handler.admincommands.impl.AdminClanHall;
import jf.gameserver.handler.admincommands.impl.AdminClientSupport;
import jf.gameserver.handler.admincommands.impl.AdminCreateItem;
import jf.gameserver.handler.admincommands.impl.AdminCursedWeapons;
import jf.gameserver.handler.admincommands.impl.AdminDelete;
import jf.gameserver.handler.admincommands.impl.AdminDisconnect;
import jf.gameserver.handler.admincommands.impl.AdminDoorControl;
import jf.gameserver.handler.admincommands.impl.AdminEditChar;
import jf.gameserver.handler.admincommands.impl.AdminEffects;
import jf.gameserver.handler.admincommands.impl.AdminEnchant;
import jf.gameserver.handler.admincommands.impl.AdminEvents;
import jf.gameserver.handler.admincommands.impl.AdminGeodata;
import jf.gameserver.handler.admincommands.impl.AdminGiveAll;
import jf.gameserver.handler.admincommands.impl.AdminGlobalEvent;
import jf.gameserver.handler.admincommands.impl.AdminGm;
import jf.gameserver.handler.admincommands.impl.AdminGmChat;
import jf.gameserver.handler.admincommands.impl.AdminHeal;
import jf.gameserver.handler.admincommands.impl.AdminHellbound;
import jf.gameserver.handler.admincommands.impl.AdminHelpPage;
import jf.gameserver.handler.admincommands.impl.AdminIP;
import jf.gameserver.handler.admincommands.impl.AdminInstance;
import jf.gameserver.handler.admincommands.impl.AdminKill;
import jf.gameserver.handler.admincommands.impl.AdminLevel;
import jf.gameserver.handler.admincommands.impl.AdminMammon;
import jf.gameserver.handler.admincommands.impl.AdminMasterwork;
import jf.gameserver.handler.admincommands.impl.AdminManor;
import jf.gameserver.handler.admincommands.impl.AdminMenu;
import jf.gameserver.handler.admincommands.impl.AdminMonsterRace;
import jf.gameserver.handler.admincommands.impl.AdminNochannel;
import jf.gameserver.handler.admincommands.impl.AdminOlympiad;
import jf.gameserver.handler.admincommands.impl.AdminPetition;
import jf.gameserver.handler.admincommands.impl.AdminPledge;
import jf.gameserver.handler.admincommands.impl.AdminPolymorph;
import jf.gameserver.handler.admincommands.impl.AdminQuests;
import jf.gameserver.handler.admincommands.impl.AdminReload;
import jf.gameserver.handler.admincommands.impl.AdminRepairChar;
import jf.gameserver.handler.admincommands.impl.AdminRes;
import jf.gameserver.handler.admincommands.impl.AdminRide;
import jf.gameserver.handler.admincommands.impl.AdminSS;
import jf.gameserver.handler.admincommands.impl.AdminScripts;
import jf.gameserver.handler.admincommands.impl.AdminServer;
import jf.gameserver.handler.admincommands.impl.AdminShop;
import jf.gameserver.handler.admincommands.impl.AdminShutdown;
import jf.gameserver.handler.admincommands.impl.AdminSkill;
import jf.gameserver.handler.admincommands.impl.AdminSpawn;
import jf.gameserver.handler.admincommands.impl.AdminTarget;
import jf.gameserver.handler.admincommands.impl.AdminTeam;
import jf.gameserver.handler.admincommands.impl.AdminTeleport;
import jf.gameserver.handler.admincommands.impl.AdminZone;
import jf.gameserver.model.Player;
import jf.gameserver.network.l2.components.CustomMessage;
import jf.gameserver.utils.Log;

public class AdminCommandHandler extends AbstractHolder
{
	private static final AdminCommandHandler _instance = new AdminCommandHandler();

	public static AdminCommandHandler getInstance()
	{
		return _instance;
	}

	private Map<String, IAdminCommandHandler> _datatable = new HashMap<String, IAdminCommandHandler>();

	private AdminCommandHandler()
	{
		registerAdminCommandHandler(new AdminAdmin());
		registerAdminCommandHandler(new AdminAnnouncements());
		registerAdminCommandHandler(new AdminAttribute());
		registerAdminCommandHandler(new AdminBan());
		registerAdminCommandHandler(new AdminCamera());
		registerAdminCommandHandler(new AdminCancel());
		registerAdminCommandHandler(new AdminChangeAccessLevel());
		registerAdminCommandHandler(new AdminCheckBot());
		registerAdminCommandHandler(new AdminClanHall());
		registerAdminCommandHandler(new AdminClientSupport());
		registerAdminCommandHandler(new AdminCreateItem());
		registerAdminCommandHandler(new AdminCursedWeapons());
		registerAdminCommandHandler(new AdminDelete());
		registerAdminCommandHandler(new AdminDisconnect());
		registerAdminCommandHandler(new AdminDoorControl());
		registerAdminCommandHandler(new AdminEditChar());
		registerAdminCommandHandler(new AdminEffects());
		registerAdminCommandHandler(new AdminEnchant());
		registerAdminCommandHandler(new AdminEvents());
		registerAdminCommandHandler(new AdminGeodata());
		registerAdminCommandHandler(new AdminGlobalEvent());
		registerAdminCommandHandler(new AdminGm());
		registerAdminCommandHandler(new AdminGmChat());
		registerAdminCommandHandler(new AdminHeal());
		registerAdminCommandHandler(new AdminHellbound());
		registerAdminCommandHandler(new AdminHelpPage());
		registerAdminCommandHandler(new AdminInstance());
		registerAdminCommandHandler(new AdminIP());
		registerAdminCommandHandler(new AdminLevel());
		registerAdminCommandHandler(new AdminMammon());
		registerAdminCommandHandler(new AdminMasterwork());
		registerAdminCommandHandler(new AdminManor());
		registerAdminCommandHandler(new AdminMenu());
		registerAdminCommandHandler(new AdminMonsterRace());
		registerAdminCommandHandler(new AdminNochannel());
		registerAdminCommandHandler(new AdminOlympiad());
		registerAdminCommandHandler(new AdminPetition());
		registerAdminCommandHandler(new AdminPledge());
		registerAdminCommandHandler(new AdminPolymorph());
		registerAdminCommandHandler(new AdminQuests());
		registerAdminCommandHandler(new AdminReload());
		registerAdminCommandHandler(new AdminRepairChar());
		registerAdminCommandHandler(new AdminRes());
		registerAdminCommandHandler(new AdminRide());
		registerAdminCommandHandler(new AdminServer());
		registerAdminCommandHandler(new AdminShop());
		registerAdminCommandHandler(new AdminShutdown());
		registerAdminCommandHandler(new AdminSkill());
		registerAdminCommandHandler(new AdminScripts());
		registerAdminCommandHandler(new AdminSpawn());
		registerAdminCommandHandler(new AdminSS());
		registerAdminCommandHandler(new AdminTarget());
		registerAdminCommandHandler(new AdminTeam());
		registerAdminCommandHandler(new AdminTeleport());
		registerAdminCommandHandler(new AdminZone());
		registerAdminCommandHandler(new AdminKill());
		registerAdminCommandHandler(new AdminGiveAll());

	}

	public void registerAdminCommandHandler(IAdminCommandHandler handler)
	{
		for(Enum<?> e : handler.getAdminCommandEnum())
			_datatable.put(e.toString().toLowerCase(), handler);
	}

	public IAdminCommandHandler getAdminCommandHandler(String adminCommand)
	{
		String command = adminCommand;
		if(adminCommand.indexOf(" ") != -1)
			command = adminCommand.substring(0, adminCommand.indexOf(" "));
		return _datatable.get(command);
	}

	public void useAdminCommandHandler(Player activeChar, String adminCommand)
	{
		if(!(activeChar.isGM() || activeChar.getPlayerAccess().CanUseGMCommand))
		{
			activeChar.sendMessage(new CustomMessage("jf.gameserver.network.l2.c2s.SendBypassBuildCmd.NoCommandOrAccess", activeChar).addString(adminCommand));
			return;
		}

		String[] wordList = adminCommand.split(" ");
		IAdminCommandHandler handler = _datatable.get(wordList[0]);
		if(handler != null)
		{
			boolean success = false;
			try
			{
				for(Enum<?> e : handler.getAdminCommandEnum())
					if(e.toString().equalsIgnoreCase(wordList[0]))
					{
						success = handler.useAdminCommand(e, wordList, adminCommand, activeChar);
						break;
					}
			}
			catch(Exception e)
			{
				error("", e);
			}
		}
	}

	@Override
	public void process()
	{

	}
	
	@Override
	public int size()
	{
		return _datatable.size();
	}

	@Override
	public void clear()
	{
		_datatable.clear();
	}

	/**
	 * Получение списка зарегистрированных админ команд
	 * @return список команд
	 */
	public Set<String> getAllCommands()
	{
		return _datatable.keySet();
	}
}