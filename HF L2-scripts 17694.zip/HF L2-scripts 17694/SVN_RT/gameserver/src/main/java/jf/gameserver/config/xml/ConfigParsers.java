package jf.gameserver.config.xml;

import jf.gameserver.config.xml.parser.HostsConfigParser;

/**
 * @author jfort
**/
public abstract class ConfigParsers
{
	public static void parseAll()
	{
		HostsConfigParser.getInstance().load();
	}
}
