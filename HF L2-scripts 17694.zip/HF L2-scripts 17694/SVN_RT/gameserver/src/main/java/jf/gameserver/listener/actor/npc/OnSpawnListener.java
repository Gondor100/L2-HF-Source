package jf.gameserver.listener.actor.npc;

import jf.gameserver.listener.NpcListener;
import jf.gameserver.model.instances.NpcInstance;

public interface OnSpawnListener extends NpcListener
{
	public void onSpawn(NpcInstance actor);
}
