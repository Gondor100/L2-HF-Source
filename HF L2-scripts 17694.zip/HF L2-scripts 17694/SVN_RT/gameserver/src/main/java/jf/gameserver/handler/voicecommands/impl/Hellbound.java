package jf.gameserver.handler.voicecommands.impl;

import jf.gameserver.Config;
import jf.gameserver.handler.voicecommands.IVoicedCommandHandler;
import jf.gameserver.instancemanager.HellboundManager;
import jf.gameserver.model.Player;
import jf.gameserver.scripts.Functions;
import jf.gameserver.network.l2.components.CustomMessage;

public class Hellbound extends Functions implements IVoicedCommandHandler
{
	private final String[] _commandList = new String[] { "hellbound" };

	@Override
	public String[] getVoicedCommandList()
	{
		return _commandList;
	}

	@Override
	public boolean useVoicedCommand(String command, Player activeChar, String target)
	{
		if(!Config.ALLOW_VOICED_COMMANDS)
			return false;
		if(command.equals("hellbound"))
		{
			activeChar.sendMessage(new CustomMessage("common.Admin.Hellbound.HBLevel", activeChar).addNumber(HellboundManager.getHellboundLevel()));
			activeChar.sendMessage(new CustomMessage("common.Admin.Hellbound.HBPoints", activeChar).addNumber(HellboundManager.getConfidence()));	
		}
		return false;
	}
}
