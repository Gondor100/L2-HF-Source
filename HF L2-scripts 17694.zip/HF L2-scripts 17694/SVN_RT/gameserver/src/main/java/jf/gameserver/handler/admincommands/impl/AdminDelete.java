package jf.gameserver.handler.admincommands.impl;

import org.apache.commons.lang3.math.NumberUtils;
import jf.gameserver.dao.SpawnsDAO;
import jf.gameserver.handler.admincommands.IAdminCommandHandler;
import jf.gameserver.model.GameObject;
import jf.gameserver.model.GameObjectsStorage;
import jf.gameserver.model.Player;
import jf.gameserver.model.Spawner;
import jf.gameserver.model.instances.NpcInstance;
import jf.gameserver.network.l2.components.SystemMsg;

public class AdminDelete implements IAdminCommandHandler
{
	private static enum Commands
	{
		admin_delete
	}

	@Override
	public boolean useAdminCommand(Enum<?> comm, String[] wordList, String fullString, Player activeChar)
	{
		Commands command = (Commands) comm;

		if(!activeChar.getPlayerAccess().CanEditNPC)
			return false;

		switch(command)
		{
			case admin_delete:
				GameObject obj = wordList.length == 1 ? activeChar.getTarget() : GameObjectsStorage.getNpc(NumberUtils.toInt(wordList[1]));
				if(obj != null && obj.isNpc())
				{
					NpcInstance target = (NpcInstance) obj;
					target.deleteMe();

					Spawner spawn = target.getSpawn();
					if(spawn != null)
						spawn.stopRespawn();

					SpawnsDAO.getInstance().delete(target);
				}
				else
					activeChar.sendPacket(SystemMsg.INVALID_TARGET);
				break;
		}

		return true;
	}

	@Override
	public Enum<?>[] getAdminCommandEnum()
	{
		return Commands.values();
	}
}