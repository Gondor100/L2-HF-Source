package jf.gameserver.listener.actor.ai;

import jf.gameserver.ai.CtrlEvent;
import jf.gameserver.listener.AiListener;
import jf.gameserver.model.Creature;

public interface OnAiEventListener extends AiListener
{
	public void onAiEvent(Creature actor, CtrlEvent evt, Object[] args);
}
