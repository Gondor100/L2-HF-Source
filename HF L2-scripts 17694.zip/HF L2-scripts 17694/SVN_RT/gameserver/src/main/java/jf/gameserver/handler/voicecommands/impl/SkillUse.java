package jf.gameserver.handler.voicecommands.impl;

import jf.gameserver.handler.voicecommands.IVoicedCommandHandler;
import jf.gameserver.model.Player;
import jf.gameserver.model.Skill;
import jf.gameserver.scripts.Functions;
import jf.gameserver.network.l2.s2c.Say2;
import jf.gameserver.network.l2.components.ChatType;
import jf.gameserver.tables.SkillTable;

/**
 * @author PaInKiLlEr
 */
public class SkillUse extends Functions implements IVoicedCommandHandler
{
	private String[] _commandList = new String[] {"useskill"};

	@Override
	public boolean useVoicedCommand(String command, Player activeChar, String args)
	{
		int skills = Integer.parseInt(args);

		Skill skill = SkillTable.getInstance().getInfo(skills, activeChar.getSkillLevel(skills));

		String sk = "/useskill " + skill.getName();
		Say2 cs = new Say2(activeChar.getObjectId(), ChatType.ALL, activeChar.getName(), sk);

		activeChar.setMacroSkill(skill);
		activeChar.sendPacket(cs);

		return true;
	}

	@Override
	public String[] getVoicedCommandList()
	{
		return _commandList;
	}
}