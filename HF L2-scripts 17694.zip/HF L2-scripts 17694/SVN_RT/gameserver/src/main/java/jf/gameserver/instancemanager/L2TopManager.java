package jf.gameserver.instancemanager;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import jf.commons.dbutils.DbUtils;
import jf.gameserver.Config;
import jf.gameserver.ThreadPoolManager;
import jf.gameserver.database.DatabaseFactory;
import jf.gameserver.model.GameObjectsStorage;
import jf.gameserver.model.Player;
import jf.gameserver.utils.ItemFunctions;

import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @reworked by jfort
**/
public class L2TopManager
{
	private class UpdateVotesData implements Runnable
	{
		@Override
		public void run()
		{
			update();
			parse(true);
			parse(false);
			clean();
			giveReward();
		}
	}

	private static final Logger _log = LoggerFactory.getLogger(L2TopManager.class);

	private final static Pattern L2TOP_PATTERN_WEB = Pattern.compile("([0-9]{4})-([0-9]{2})-([0-9]{2}) +([0-9]{2}):([0-9]{2}):([0-9]{2})\t+(\\S+)\\s+", Pattern.DOTALL | Pattern.MULTILINE | Pattern.UNICODE_CASE);
	private final static Pattern L2TOP_PATTERN_SMS = Pattern.compile("([0-9]{4})-([0-9]{2})-([0-9]{2}) +([0-9]{2}):([0-9]{2}):([0-9]{2})\t+(\\S+)\t+x([0-9]+)\\s+", Pattern.DOTALL | Pattern.MULTILINE | Pattern.UNICODE_CASE);

	private final static String VOTE_WEB_FILE = Config.DATAPACK_ROOT + "/data/l2top_vote-web.txt";
	private final static String VOTE_SMS_FILE = Config.DATAPACK_ROOT + "/data/l2top_vote-sms.txt";

	private static L2TopManager _instance;

	public static L2TopManager getInstance()
	{
		if(_instance == null && Config.L2_TOP_MANAGER_ENABLED)
			_instance = new L2TopManager();
		return _instance;
	}

	private L2TopManager()
	{
		ThreadPoolManager.getInstance().scheduleAtFixedRate(new UpdateVotesData(), Config.L2_TOP_MANAGER_INTERVAL, Config.L2_TOP_MANAGER_INTERVAL);
		_log.info("L2TopManager: Loaded sucesfully.");
	}

	private void update()
	{
		String smsPage = getPage(Config.L2_TOP_SMS_ADDRESS);
		if(smsPage == null)
			_log.error(getClass().getSimpleName() + ": Error while loading vote sms list page!");
		else
		{
			try
			{
				File file = new File(VOTE_SMS_FILE);
				if(!file.exists())
					file.createNewFile();
				FileOutputStream fos = new FileOutputStream(file);
				fos.write(smsPage.getBytes("UTF-8"));
				fos.close();
			}
			catch(IOException e)
			{
				//
			}
		}

		String webPage = getPage(Config.L2_TOP_WEB_ADDRESS);
		if(webPage == null)
			_log.error(getClass().getSimpleName() + ": Error while loading vote web list page!");
		else
		{
			try
			{
				File file = new File(VOTE_WEB_FILE);
				if(!file.exists())
					file.createNewFile();
				FileOutputStream fos = new FileOutputStream(file);
				fos.write(webPage.getBytes("UTF-8"));
				fos.close();
			}
			catch(IOException e)
			{
				//
			}
		}
	}

	private static String getPage(String address)
	{
		StringBuffer buf = new StringBuffer();
		Socket s;
		try
		{
			s = new Socket("l2top.ru", 80);

			s.setSoTimeout(30000);
			String request = "GET " + address + " HTTP/1.1\r\n" + "User-Agent: http:\\" + Config.EXTERNAL_HOSTNAME + " server\r\n" + "Host: http:\\" + Config.EXTERNAL_HOSTNAME + " \r\n" + "Accept: */*\r\n" + "Connection: close\r\n" + "\r\n";
			s.getOutputStream().write(request.getBytes());
			BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream(), "Cp1251"));

			for(String line = in.readLine(); line != null; line = in.readLine())
			{
				buf.append(line);
				buf.append("\r\n");
			}
			s.close();
		}
		catch(Exception e)
		{
			return null;
		}
		return buf.toString();
	}

	private void parse(boolean sms)
	{
		try
		{
			File file = new File(sms ? VOTE_SMS_FILE : VOTE_WEB_FILE);
			String txt = FileUtils.readFileToString(file, "UTF-8");
			Matcher matcher = sms ? L2TOP_PATTERN_SMS.matcher(txt) : L2TOP_PATTERN_WEB.matcher(txt);
			while(matcher.find())
			{
				Calendar calendar = Calendar.getInstance();
				calendar.set(Calendar.YEAR, Integer.parseInt(matcher.group(1)));
				calendar.set(Calendar.MONTH, Integer.parseInt(matcher.group(2)));
				calendar.set(Calendar.DAY_OF_MONTH, Integer.parseInt(matcher.group(3)));
				calendar.set(Calendar.HOUR_OF_DAY, Integer.parseInt(matcher.group(4)));
				calendar.set(Calendar.MINUTE, Integer.parseInt(matcher.group(5)));
				calendar.set(Calendar.SECOND, Integer.parseInt(matcher.group(6)));
				calendar.set(Calendar.MILLISECOND, 0);

				String serverPrefix;
				String nickName;

				StringTokenizer st = new StringTokenizer(matcher.group(7), "-");
				if(st.countTokens() == 1)
				{
					serverPrefix = "";
					nickName = st.nextToken();
				}
				else if(st.countTokens() == 2)
				{
					serverPrefix = st.nextToken();
					nickName = st.nextToken();
				}
				else
				{
					_log.warn(getClass().getSimpleName() + ": Uncorrect voted nickname: " + matcher.group(7));
					continue;
				}

				if(Config.L2_TOP_NAME_PREFIX.isEmpty() || Config.L2_TOP_NAME_PREFIX.equalsIgnoreCase(serverPrefix))
				{
					int mult = sms ? Integer.parseInt(matcher.group(8)) : 1;
					if((calendar.getTimeInMillis() + (Config.L2_TOP_SAVE_DAYS * 24 * 60 * 60 * 1000L)) > System.currentTimeMillis())
						checkAndSaveFromDb(calendar.getTimeInMillis(), nickName, mult);
				}
			}
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
	}

	private synchronized void clean()
	{
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_YEAR, -Config.L2_TOP_SAVE_DAYS);
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rset = null;
		try
		{
			con = DatabaseFactory.getInstance().getConnection();
			statement = con.prepareStatement("DELETE FROM character_l2top_votes WHERE date < ?");
			statement.setLong(1, calendar.getTimeInMillis());
			statement.execute();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			DbUtils.closeQuietly(con, statement, rset);
		}
	}

	private synchronized void checkAndSaveFromDb(long date, String nick, int mult)
	{
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rset = null;
		try
		{
			con = DatabaseFactory.getInstance().getConnection();
			statement = con.prepareStatement("SELECT obj_Id,char_name FROM characters WHERE LCASE(char_name) LIKE LCASE(?)");
			statement.setString(1, nick);
			rset = statement.executeQuery();
			if(rset.next())
			{
				int objId = rset.getInt("obj_Id");
				String charName = rset.getString("char_name");

				DbUtils.closeQuietly(statement, rset);

				statement = con.prepareStatement("SELECT * FROM character_l2top_votes WHERE id=? AND date=? AND multipler=?");
				statement.setInt(1, objId);
				statement.setLong(2, date);
				statement.setInt(3, mult);
				rset = statement.executeQuery();
				if(!rset.next())
				{
					DbUtils.closeQuietly(statement, rset);
					statement = con.prepareStatement("INSERT INTO character_l2top_votes (date, id, nick, multipler) values (?,?,?,?)");
					statement.setLong(1, date);
					statement.setInt(2, objId);
					statement.setString(3, charName);
					statement.setInt(4, mult);
					statement.execute();
				}
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			DbUtils.closeQuietly(con, statement, rset);
		}
	}

	private synchronized void giveReward()
	{
		Connection con = null;
		PreparedStatement statement = null;
		ResultSet rset = null;
		try
		{
			con = DatabaseFactory.getInstance().getConnection();
			for(Player player : GameObjectsStorage.getAllPlayers())
			{
				int objId = player.getObjectId();
				int mult = 0;
				statement = con.prepareStatement("SELECT multipler FROM character_l2top_votes WHERE id=? AND has_reward=0");
				statement.setInt(1, objId);
				rset = statement.executeQuery();
				while(rset.next())
					mult += rset.getInt("multipler");

				DbUtils.closeQuietly(statement, rset);
				statement = con.prepareStatement("UPDATE character_l2top_votes SET has_reward=1 WHERE id=?");
				statement.setInt(1, objId);
				statement.executeUpdate();
				if(mult > 0)
				{
					if(player.isLangRus())
						player.sendMessage("Администрация сервера " + Config.L2_TOP_SERVER_ADDRESS + " благодарит вас за голосование!");
					else
						player.sendMessage("The administration server " + Config.L2_TOP_SERVER_ADDRESS + " thank you for your vote!");

					for(int i = 0; i < Config.L2_TOP_REWARD.length; i += 2)
						ItemFunctions.addItem(player, Config.L2_TOP_REWARD[i], Config.L2_TOP_REWARD[i + 1] * mult, true);
				}
				DbUtils.closeQuietly(statement);
			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			DbUtils.closeQuietly(con, statement, rset);
		}
	}
}