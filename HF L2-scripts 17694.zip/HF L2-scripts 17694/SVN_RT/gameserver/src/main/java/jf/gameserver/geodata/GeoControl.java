package jf.gameserver.geodata;

import java.util.HashMap;

import jf.commons.geometry.Shape;

public interface GeoControl
{
	public abstract Shape getGeoShape();

	public abstract HashMap<Long, Byte> getGeoAround();

	public abstract void setGeoAround(HashMap<Long, Byte> value);

	public abstract int getGeoIndex();
}