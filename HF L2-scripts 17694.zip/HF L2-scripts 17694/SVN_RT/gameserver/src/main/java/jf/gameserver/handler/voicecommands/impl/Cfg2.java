package jf.gameserver.handler.voicecommands.impl;

import jf.gameserver.data.htm.HtmCache;
import jf.gameserver.handler.voicecommands.IVoicedCommandHandler;
import jf.gameserver.model.Player;
import jf.gameserver.model.entity.CharacterControlPanel;
import jf.gameserver.scripts.Functions;

public class Cfg2 extends Functions implements IVoicedCommandHandler
{
	private static final String[] COMMANDS = { "cp", "cfg" };
  
	@Override
	public boolean useVoicedCommand(String command, Player activeChar, String args)
	{
		String nextPage = CharacterControlPanel.getInstance().useCommand(activeChar, args, "-h user_cp "); 
		if((nextPage == null) || (nextPage.isEmpty()))
		{
			return true;
		}
		String html = "command/" + nextPage;
    
		String dialog = HtmCache.getInstance().getHtml(html, activeChar);
    
		String additionalText = args.split(" ").length > 1 ? args.split(" ")[1] : "";
		dialog = CharacterControlPanel.getInstance().replacePage(dialog, activeChar, additionalText, "-h user_cp ");
    
		show(dialog, activeChar);
    
		return true;
	}
  
	@Override
	public String[] getVoicedCommandList()
	{
		return COMMANDS;
	}
}
