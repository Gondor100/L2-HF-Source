package jf.gameserver.data.xml;

import jf.gameserver.data.htm.HtmCache;
import jf.gameserver.data.string.ItemNameHolder;
import jf.gameserver.data.string.SkillDescHolder;
import jf.gameserver.data.string.SkillNameHolder;
import jf.gameserver.data.string.StringsHolder;
import jf.gameserver.data.xml.holder.BuyListHolder;
import jf.gameserver.data.xml.holder.MultiSellHolder;
import jf.gameserver.data.xml.holder.ProductHolder;
import jf.gameserver.data.xml.parser.AirshipDockParser;
import jf.gameserver.data.xml.parser.ArmorSetsParser;
import jf.gameserver.data.xml.parser.ClassDataParser;
import jf.gameserver.data.xml.parser.CubicParser;
import jf.gameserver.data.xml.parser.DomainParser;
import jf.gameserver.data.xml.parser.DoorParser;
import jf.gameserver.data.xml.parser.EnchantItemParser;
import jf.gameserver.data.xml.parser.EventParser;
import jf.gameserver.data.xml.parser.FakeItemParser;
import jf.gameserver.data.xml.parser.FakePlayersParser;
import jf.gameserver.data.xml.parser.FightClubMapParser;
import jf.gameserver.data.xml.parser.FishDataParser;
import jf.gameserver.data.xml.parser.HennaParser;
import jf.gameserver.data.xml.parser.InstantZoneParser;
import jf.gameserver.data.xml.parser.ItemParser;
import jf.gameserver.data.xml.parser.LevelBonusParser;
import jf.gameserver.data.xml.parser.MoveRouteParser;
import jf.gameserver.data.xml.parser.NpcParser;
import jf.gameserver.data.xml.parser.OptionDataParser;
import jf.gameserver.data.xml.parser.PetitionGroupParser;
import jf.gameserver.data.xml.parser.PlayerTemplateParser;
import jf.gameserver.data.xml.parser.PremiumAccountParser;
import jf.gameserver.data.xml.parser.RecipeParser;
import jf.gameserver.data.xml.parser.ResidenceParser;
import jf.gameserver.data.xml.parser.RestartPointParser;
import jf.gameserver.data.xml.parser.SkillAcquireParser;
import jf.gameserver.data.xml.parser.SoulCrystalParser;
import jf.gameserver.data.xml.parser.SpawnParser;
import jf.gameserver.data.xml.parser.StaticObjectParser;
import jf.gameserver.data.xml.parser.VariationDataParser;
import jf.gameserver.data.xml.parser.ZoneParser;
import jf.gameserver.instancemanager.ReflectionManager;
import jf.gameserver.tables.SkillTable;

/**
 * @author VISTALL
 * @date  20:55/30.11.2010
 */
public abstract class Parsers
{
	public static void parseAll()
	{
		HtmCache.getInstance().reload();
		StringsHolder.getInstance().load();
		ItemNameHolder.getInstance().load();
		SkillNameHolder.getInstance().load();
		SkillDescHolder.getInstance().load();
		//
		SkillTable.getInstance().load(); // - SkillParser.getInstance();
		OptionDataParser.getInstance().load();
		VariationDataParser.getInstance().load();
		ItemParser.getInstance().load();
		RecipeParser.getInstance().load();
		//
		LevelBonusParser.getInstance().load();
		PlayerTemplateParser.getInstance().load();
		ClassDataParser.getInstance().load();
		NpcParser.getInstance().load();

		DomainParser.getInstance().load();
		RestartPointParser.getInstance().load();

		StaticObjectParser.getInstance().load();
		DoorParser.getInstance().load();
		ZoneParser.getInstance().load();
		SpawnParser.getInstance().load();
		InstantZoneParser.getInstance().load();

		ReflectionManager.getInstance();
		//
		AirshipDockParser.getInstance().load();
		SkillAcquireParser.getInstance().load();
		//
		ResidenceParser.getInstance().load();
		EventParser.getInstance().load();
		FightClubMapParser.getInstance().load();
		// support(cubic & agathion)
		CubicParser.getInstance().load();
		//
		BuyListHolder.getInstance();
		MultiSellHolder.getInstance();
		ProductHolder.getInstance();
		// AgathionParser.getInstance();
		// item support
		HennaParser.getInstance().load();
		EnchantItemParser.getInstance().load();
		SoulCrystalParser.getInstance().load();
		ArmorSetsParser.getInstance().load();
		FishDataParser.getInstance().load();

		PremiumAccountParser.getInstance().load();
		
		// etc
		PetitionGroupParser.getInstance().load();

		// Fake players
		FakeItemParser.getInstance().load();
		FakePlayersParser.getInstance().load();
		MoveRouteParser.getInstance().load();
	}
}
