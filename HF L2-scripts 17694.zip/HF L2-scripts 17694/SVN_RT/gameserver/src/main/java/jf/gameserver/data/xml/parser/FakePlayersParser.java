package jf.gameserver.data.xml.parser;

import java.io.File;
import java.util.Iterator;

import jf.commons.data.xml.AbstractParser;
import jf.gameserver.Config;
import jf.gameserver.data.xml.holder.FakePlayersHolder;
import jf.gameserver.templates.fakeplayer.FakePlayerAITemplate;
import jf.gameserver.templates.fakeplayer.FarmZoneTemplate;
import jf.gameserver.templates.fakeplayer.TownZoneTemplate;

import org.dom4j.Element;

/**
 * @author jfort
**/
public final class FakePlayersParser extends AbstractParser<FakePlayersHolder>
{
	private static final FakePlayersParser _instance = new FakePlayersParser();

	public static FakePlayersParser getInstance()
	{
		return _instance;
	}

	private FakePlayersParser()
	{
		super(FakePlayersHolder.getInstance());
	}

	@Override
	public File getXMLPath()
	{
		return new File(Config.DATAPACK_ROOT, "data/fake_players/");
	}

	@Override
	public boolean isIgnored(File f)
	{
		if(f.equals(FakeItemParser.getInstance().getXMLPath()))
			return true;
		return false;
	}

	@Override
	public String getDTDFileName()
	{
		return "fake_player.dtd";
	}

	@Override
	protected void readData(Element rootElement) throws Exception
	{
		String rootElementName = rootElement.getName();
		if(rootElementName.equalsIgnoreCase("fake_player_ai"))
		{
			FakePlayerAITemplate template = FakePlayerAITemplate.parse(rootElement);
			if(template != null)
				getHolder().addAITemplate(template);
		}
		else if(rootElementName.equalsIgnoreCase("farm"))
		{
			getHolder().addFarmZone(FarmZoneTemplate.parse(rootElement));
		}
		else if(rootElementName.equalsIgnoreCase("town"))
		{
			getHolder().addTownZone(TownZoneTemplate.parse(rootElement));
		}
	}

	@Override
	protected void afterParseActions()
	{
		for(FakePlayerAITemplate aiTemplate : getHolder().getAITemplates())
		{
			for(FarmZoneTemplate farmTemplate : getHolder().getFarmZones())
				aiTemplate.addFarmZone(farmTemplate);
		}
	}
}
