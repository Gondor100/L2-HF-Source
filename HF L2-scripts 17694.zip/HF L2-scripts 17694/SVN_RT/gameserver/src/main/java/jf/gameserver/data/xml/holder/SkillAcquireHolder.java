package jf.gameserver.data.xml.holder;

import gnu.trove.iterator.TIntObjectIterator;
import gnu.trove.map.TIntObjectMap;
import gnu.trove.map.hash.TIntObjectHashMap;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import jf.commons.data.xml.AbstractHolder;
import jf.gameserver.model.pledge.Clan;
import jf.gameserver.model.Player;
import jf.gameserver.model.Skill;
import jf.gameserver.model.SkillLearn;
import jf.gameserver.model.base.AcquireType;
import jf.gameserver.model.base.ClassId;
import jf.gameserver.model.pledge.SubUnit;


/**
 * @author: VISTALL
 * @date:  20:55/30.11.2010
 */
public final class SkillAcquireHolder extends AbstractHolder
{
	private static final SkillAcquireHolder _instance = new SkillAcquireHolder();

	public static SkillAcquireHolder getInstance()
	{
		return _instance;
	}

	// классовые зависимости
	private TIntObjectMap<Set<SkillLearn>> _normalSkillTree = new TIntObjectHashMap<Set<SkillLearn>>();
	private TIntObjectMap<Set<SkillLearn>> _transferSkillTree = new TIntObjectHashMap<Set<SkillLearn>>();
	// расовые зависимости
	private TIntObjectMap<Set<SkillLearn>> _fishingSkillTree = new TIntObjectHashMap<Set<SkillLearn>>();
	private TIntObjectMap<Set<SkillLearn>> _transformationSkillTree = new TIntObjectHashMap<Set<SkillLearn>>();
	// без зависимостей
	private Set<SkillLearn> _certificationSkillTree = new HashSet<SkillLearn>();
	private Set<SkillLearn> _rebornSkillTree = new HashSet<SkillLearn>();
	private Set<SkillLearn> _collectionSkillTree = new HashSet<SkillLearn>();
	private Set<SkillLearn> _pledgeSkillTree = new HashSet<SkillLearn>();
	private Set<SkillLearn> _subUnitSkillTree = new HashSet<SkillLearn>();
	private Set<SkillLearn> _gmSkillTree = new HashSet<SkillLearn>();

	public int getMinLevelForNewSkill(Player player, AcquireType type)
	{
		Set<SkillLearn> skills;
		switch(type)
		{
			case NORMAL:
				skills = _normalSkillTree.get(player.getActiveClassId());
				if(skills == null)
				{
					info("skill tree for class " + player.getActiveClassId() + " is not defined !");
					return 0;
				}
				break;
			case TRANSFORMATION:
				skills = _transformationSkillTree.get(player.getRace().ordinal());
				if(skills == null)
				{
					info("skill tree for race " + player.getRace().ordinal() + " is not defined !");
					return 0;
				}
				break;
			case FISHING:
				skills = _fishingSkillTree.get(player.getRace().ordinal());
				if(skills == null)
				{
					info("skill tree for race " + player.getRace().ordinal() + " is not defined !");
					return 0;
				}
				break;
			default:
				return 0;
		}
		int minlevel = 0;
		for(SkillLearn temp : skills)
			if(temp.getMinLevel() > player.getLevel())
				if(minlevel == 0 || temp.getMinLevel() < minlevel)
					minlevel = temp.getMinLevel();
		return minlevel;
	}

	public Collection<SkillLearn> getAvailableSkills(Player player, AcquireType type)
	{
		return getAvailableSkills(player, type, null);
	}

	public Collection<SkillLearn> getAvailableSkills(Player player, AcquireType type, SubUnit subUnit)
	{
		Collection<SkillLearn> skills;
		switch(type)
		{
			case NORMAL:
				skills = _normalSkillTree.get(player.getActiveClassId());
				if(skills == null)
				{
					info("skill tree for class " + player.getActiveClassId() + " is not defined !");
					return Collections.emptyList();
				}
				return getAvaliableList(skills, player.getAllSkillsArray(), player.getLevel());
			case COLLECTION:
				skills = _collectionSkillTree;
				if(skills == null)
				{
					info("skill tree for class " + player.getActiveClassId() + " is not defined !");
					return Collections.emptyList();
				}
				return getAvaliableList(skills, player.getAllSkillsArray(), player.getLevel());
			case TRANSFORMATION:
				skills = _transformationSkillTree.get(player.getRace().ordinal());
				if(skills == null)
				{
					info("skill tree for race " + player.getRace().ordinal() + " is not defined !");
					return Collections.emptyList();
				}
				return getAvaliableList(skills, player.getAllSkillsArray(), player.getLevel());
			case TRANSFER_EVA_SAINTS:
			case TRANSFER_SHILLIEN_SAINTS:
			case TRANSFER_CARDINAL:
				skills = _transferSkillTree.get(type.transferClassId());
				if(skills == null)
				{
					info("skill tree for class " + type.transferClassId() + " is not defined !");
					return Collections.emptyList();
				}
				if(player == null)
					return skills;
				else
				{
					Map<Integer, SkillLearn> skillLearnMap = new TreeMap<Integer, SkillLearn>();
					for(SkillLearn temp : skills)
						if(temp.getMinLevel() <= player.getLevel())
						{
							int knownLevel = player.getSkillLevel(temp.getId());
							if(knownLevel == -1)
								skillLearnMap.put(temp.getId(), temp);
						}

					return skillLearnMap.values();
				}
			case FISHING:
				skills = _fishingSkillTree.get(player.getRace().ordinal());
				if(skills == null)
				{
					info("skill tree for race " + player.getRace().ordinal() + " is not defined !");
					return Collections.emptyList();
				}
				return getAvaliableList(skills, player.getAllSkillsArray(), player.getLevel());
			case CLAN:
				skills = _pledgeSkillTree;
				Collection<Skill> skls = player.getClan().getSkills(); //TODO [VISTALL] придумать другой способ

				return getAvaliableList(skills, skls.toArray(new Skill[skls.size()]), player.getClan().getLevel());
			case SUB_UNIT:
				skills = _subUnitSkillTree;
				Collection<Skill> st = subUnit.getSkills(); //TODO [VISTALL] придумать другой способ

				return getAvaliableList(skills, st.toArray(new Skill[st.size()]), player.getClan().getLevel());
			case CERTIFICATION:
				skills = _certificationSkillTree;
				if(player == null)
					return skills;
				else
					return getAvaliableList(skills, player.getAllSkillsArray(), player.getLevel());
			case REBORN:
				skills = _rebornSkillTree;
				if(player == null)
					return skills;
				else
					return getAvaliableList(skills, player.getAllSkillsArray(), player.getLevel());	
			case GM:
				skills = _gmSkillTree;
				if(player == null)
					return skills;
				else
					return getAvaliableList(skills, player.getAllSkillsArray(), player.getLevel());
			default:
				return Collections.emptyList();
		}
	}

	private Collection<SkillLearn> getAvaliableList(Collection<SkillLearn> skillLearns, Skill[] skills, int level)
	{
		Map<Integer, SkillLearn> skillLearnMap = new TreeMap<Integer, SkillLearn>();
		for(SkillLearn temp : skillLearns)
			if(temp.getMinLevel() <= level)
			{
				boolean knownSkill = false;
				for(int j = 0; j < skills.length && !knownSkill; j++)
					if(skills[j].getId() == temp.getId())
					{
						knownSkill = true;
						if(skills[j].getLevel() == temp.getLevel() - 1)
							skillLearnMap.put(temp.getId(), temp);
					}
				if(!knownSkill && temp.getLevel() == 1)
					skillLearnMap.put(temp.getId(), temp);
			}

		return skillLearnMap.values();
	}

	public Collection<SkillLearn> getAvailableMaxLvlSkills(Player player, AcquireType type)
	{
		return getAvailableMaxLvlSkills(player, type, null);
	}

	public Collection<SkillLearn> getAvailableMaxLvlSkills(Player player, AcquireType type, SubUnit subUnit)
	{
		Collection<SkillLearn> skills;
		switch(type)
		{
			case NORMAL:
				skills = _normalSkillTree.get(player.getActiveClassId());
				if(skills == null)
				{
					info("skill tree for class " + player.getActiveClassId() + " is not defined !");
					return Collections.emptyList();
				}
				return getAvaliableMaxLvlSkillList(skills, player.getAllSkillsArray(), player.getLevel());
			case COLLECTION:
				skills = _collectionSkillTree;
				if(skills == null)
				{
					info("skill tree for class " + player.getActiveClassId() + " is not defined !");
					return Collections.emptyList();
				}
				return getAvaliableMaxLvlSkillList(skills, player.getAllSkillsArray(), player.getLevel());
			case TRANSFORMATION:
				skills = _transformationSkillTree.get(player.getRace().ordinal());
				if(skills == null)
				{
					info("skill tree for race " + player.getRace().ordinal() + " is not defined !");
					return Collections.emptyList();
				}
				return getAvaliableMaxLvlSkillList(skills, player.getAllSkillsArray(), player.getLevel());
			case TRANSFER_EVA_SAINTS:
			case TRANSFER_SHILLIEN_SAINTS:
			case TRANSFER_CARDINAL:
				skills = _transferSkillTree.get(type.transferClassId());
				if(skills == null)
				{
					info("skill tree for class " + type.transferClassId() + " is not defined !");
					return Collections.emptyList();
				}
				if(player == null)
					return skills;
				else
				{
					Map<Integer, SkillLearn> skillLearnMap = new TreeMap<Integer, SkillLearn>();
					for(SkillLearn temp : skills)
						if(temp.getMinLevel() <= player.getLevel())
						{
							int knownLevel = player.getSkillLevel(temp.getId());
							if(knownLevel == -1)
								skillLearnMap.put(temp.getId(), temp);
						}

					return skillLearnMap.values();
				}
			case FISHING:
				skills = _fishingSkillTree.get(player.getRace().ordinal());
				if(skills == null)
				{
					info("skill tree for race " + player.getRace().ordinal() + " is not defined !");
					return Collections.emptyList();
				}
				return getAvaliableMaxLvlSkillList(skills, player.getAllSkillsArray(), player.getLevel());
			case CLAN:
				skills = _pledgeSkillTree;
				Collection<Skill> skls = player.getClan().getSkills(); //TODO [VISTALL] придумать другой способ

				return getAvaliableMaxLvlSkillList(skills, skls.toArray(new Skill[skls.size()]), player.getClan().getLevel());
			case SUB_UNIT:
				skills = _subUnitSkillTree;
				Collection<Skill> st = subUnit.getSkills(); //TODO [VISTALL] придумать другой способ

				return getAvaliableMaxLvlSkillList(skills, st.toArray(new Skill[st.size()]), player.getClan().getLevel());
			case CERTIFICATION:
				skills = _certificationSkillTree;
				if(player == null)
					return skills;
				else
					return getAvaliableMaxLvlSkillList(skills, player.getAllSkillsArray(), player.getLevel());
			case REBORN:
				skills = _rebornSkillTree;
				if(player == null)
					return skills;
				else
					return getAvaliableMaxLvlSkillList(skills, player.getAllSkillsArray(), player.getLevel());	
			case GM:
				skills = _gmSkillTree;
				if(player == null)
					return skills;
				else
					return getAvaliableMaxLvlSkillList(skills, player.getAllSkillsArray(), player.getLevel());
			default:
				return Collections.emptyList();
		}
	}

	private Collection<SkillLearn> getAvaliableMaxLvlSkillList(Collection<SkillLearn> skillLearns, Skill[] skills, int level)
	{
		Map<Integer, SkillLearn> skillLearnMap = new TreeMap<Integer, SkillLearn>();
		for(SkillLearn temp : skillLearns)
		{
			int skillId = temp.getId();
			if(!skillLearnMap.containsKey(skillId) || temp.getLevel() > skillLearnMap.get(skillId).getLevel())
				skillLearnMap.put(skillId, temp);
		}

		for(Skill skill : skills)
		{
			int skillId = skill.getId();
			if(!skillLearnMap.containsKey(skillId))
				continue;

			SkillLearn temp = skillLearnMap.get(skillId);
			if(temp == null)
				continue;

			if(temp.getLevel() <= skill.getLevel())
				skillLearnMap.remove(skillId);
		}

		return skillLearnMap.values();
	}

	public SkillLearn getSkillLearn(Player player, int id, int level, AcquireType type)
	{
		Set<SkillLearn> skills;
		switch(type)
		{
			case NORMAL:
				skills = _normalSkillTree.get(player.getActiveClassId());
				break;
			case COLLECTION:
				skills = _collectionSkillTree;
				break;
			case TRANSFORMATION:
				skills = _transformationSkillTree.get(player.getRace().ordinal());
				break;
			case TRANSFER_CARDINAL:
			case TRANSFER_SHILLIEN_SAINTS:
			case TRANSFER_EVA_SAINTS:
				skills = _transferSkillTree.get(player.getActiveClassId());
				break;
			case FISHING:
				skills = _fishingSkillTree.get(player.getRace().ordinal());
				break;
			case CLAN:
				skills = _pledgeSkillTree;
				break;
			case SUB_UNIT:
				skills = _subUnitSkillTree;
				break;
			case CERTIFICATION:
				skills = _certificationSkillTree;
				break;
			case REBORN:
				skills = _rebornSkillTree;
				break;	
			case GM:
				skills = _gmSkillTree;
				break;
			default:
				return null;
		}

		if(skills == null)
			return null;

		for(SkillLearn temp : skills)
			if(temp.getLevel() == level && temp.getId() == id)
				return temp;

		return null;
	}

	public boolean isSkillPossible(Player player, Skill skill, AcquireType type)
	{
		Clan clan = null;
		Set<SkillLearn> skills;
		switch(type)
		{
			case NORMAL:
				skills = _normalSkillTree.get(player.getActiveClassId());
				break;
			case COLLECTION:
				skills = _collectionSkillTree;
				break;
			case TRANSFORMATION:
				skills = _transformationSkillTree.get(player.getRace().ordinal());
				break;
			case FISHING:
				skills = _fishingSkillTree.get(player.getRace().ordinal());
				break;
			case TRANSFER_CARDINAL:
			case TRANSFER_EVA_SAINTS:
			case TRANSFER_SHILLIEN_SAINTS:
				int transferId = type.transferClassId();
				if(player.getActiveClassId() != transferId)
					return false;

				skills = _transferSkillTree.get(transferId);
				break;
			case CLAN:
				clan = player.getClan();
				if(clan == null)
					return false;
				skills = _pledgeSkillTree;
				break;
			case SUB_UNIT:
				clan = player.getClan();
				if(clan == null)
					return false;

				skills = _subUnitSkillTree;
				break;
			case CERTIFICATION:
				skills = _certificationSkillTree;
				break;
			case REBORN:
				skills = _rebornSkillTree;
				break;
			case GM:
				if(!player.isGM())
					return false;
				skills = _gmSkillTree;
				break;				
			default:
				return false;
		}

		return isSkillPossible(skills, skill);
	}

	private boolean isSkillPossible(Collection<SkillLearn> skills, Skill skill)
	{
		for(SkillLearn learn : skills)
			if(learn.getId() == skill.getId() && learn.getLevel() <= skill.getLevel())
				return true;
		return false;
	}

	public boolean isSkillPossible(Player player, Skill skill)
	{
		for(AcquireType aq : AcquireType.VALUES)
			if(isSkillPossible(player, skill, aq))
				return true;

		return false;
	}

	public List<SkillLearn> getSkillLearnListByItemId(Player player, int itemId)
	{
		Set<SkillLearn> learns = _normalSkillTree.get(player.getActiveClassId());
		List<SkillLearn> l = new ArrayList<SkillLearn>(1);
		
		for(SkillLearn learning : _collectionSkillTree)
		{
			if(learning.isClicked() && learning.getItemId() == itemId)
				l.add(learning);
		}

		if(!l.isEmpty())
			return l;
			
		if(learns == null || learns.isEmpty())
			return Collections.emptyList();

		for(SkillLearn $i : learns)
		{
			if($i.getItemId() == itemId)
				l.add($i);
		}
				
		return l;
	}

	public List<SkillLearn> getAllNormalSkillTreeWithForgottenScrolls()
	{
		List<SkillLearn> a = new ArrayList<SkillLearn>();
		for(TIntObjectIterator<Set<SkillLearn>> i = _normalSkillTree.iterator(); i.hasNext();)
		{
			i.advance();
			for(SkillLearn learn : i.value())
				if(learn.getItemId() > 0 && learn.isClicked())
					a.add(learn);
		}	

		for(SkillLearn learning : _collectionSkillTree)
		{
			if(learning.getItemId() > 0 && learning.isClicked())
				a.add(learning);
		}		

		return a;
	}

	public void addAllNormalSkillLearns(TIntObjectMap<Set<SkillLearn>> map)
	{
		int classID;

		for(ClassId classId : ClassId.VALUES)
		{
			if(classId.getRace() == null)
				continue;

			classID = classId.getId();

			Set<SkillLearn> temp;

			temp = map.get(classID);
			if(temp == null)
			{
				info("Not found NORMAL skill learn for class " + classID);
				continue;
			}

			_normalSkillTree.put(classId.getId(), temp);

			ClassId secondparent = classId.getParent(1);
			if(secondparent == classId.getParent(0))
				secondparent = null;

			classId = classId.getParent(0);

			while(classId != null)
			{
				Set<SkillLearn> parentList = _normalSkillTree.get(classId.getId());
				temp.addAll(parentList);

				classId = classId.getParent(0);
				if(classId == null && secondparent != null)
				{
					classId = secondparent;
					secondparent = secondparent.getParent(1);
				}
			}
		}
	}

	public void addAllFishingLearns(int race, Set<SkillLearn> s)
	{
		_fishingSkillTree.put(race, s);
	}

	public void addAllTransferLearns(int classId, Set<SkillLearn> s)
	{
		_transferSkillTree.put(classId, s);
	}

	public void addAllTransformationLearns(int race, Set<SkillLearn> s)
	{
		_transformationSkillTree.put(race, s);
	}

	public void addAllCertificationLearns(Set<SkillLearn> s)
	{
		_certificationSkillTree.addAll(s);
	}
	
	public void addAllRebornLearns(Set<SkillLearn> s)
	{
		_rebornSkillTree.addAll(s);
	}
	
	public void addAllCollectionLearns(Set<SkillLearn> s)
	{
		_collectionSkillTree.addAll(s);
	}

	public void addAllSubUnitLearns(Set<SkillLearn> s)
	{
		_subUnitSkillTree.addAll(s);
	}

	public void addAllPledgeLearns(Set<SkillLearn> s)
	{
		_pledgeSkillTree.addAll(s);
	}

	public void addAllGMLearns(Set<SkillLearn> s)
	{
		_gmSkillTree.addAll(s);
	}

	@Override
	public void log()
	{
		info("load " + sizeTroveMap(_normalSkillTree) + " normal learns for " + _normalSkillTree.size() + " classes.");
		info("load " + sizeTroveMap(_transferSkillTree) + " transfer learns for " + _transferSkillTree.size() + " classes.");
		//
		info("load " + sizeTroveMap(_transformationSkillTree) + " transformation learns for " + _transformationSkillTree.size() + " races.");
		info("load " + sizeTroveMap(_fishingSkillTree) + " fishing learns for " + _fishingSkillTree.size() + " races.");
		//
		info("load " + _certificationSkillTree.size() + " certification learns.");
		info("load " + _collectionSkillTree.size() + " collection learns.");
		info("load " + _pledgeSkillTree.size() + " pledge learns.");
		info("load " + _subUnitSkillTree.size() + " sub unit learns.");
		info("load " + _gmSkillTree.size() + " GM skills learns.");
	}

	@Deprecated
	@Override
	public int size()
	{
		return 0;
	}

	@Override
	public void clear()
	{
		_normalSkillTree.clear();
		_fishingSkillTree.clear();
		_transferSkillTree.clear();
		_certificationSkillTree.clear();
		_collectionSkillTree.clear();
		_pledgeSkillTree.clear();
		_subUnitSkillTree.clear();
		_gmSkillTree.clear();
	}

	private int sizeTroveMap(TIntObjectMap<Set<SkillLearn>> a)
	{
		int i = 0;
		for(TIntObjectIterator<Set<SkillLearn>> iterator = a.iterator(); iterator.hasNext();)
		{
			iterator.advance();
			i += iterator.value().size();
		}

		return i;
	}
}
