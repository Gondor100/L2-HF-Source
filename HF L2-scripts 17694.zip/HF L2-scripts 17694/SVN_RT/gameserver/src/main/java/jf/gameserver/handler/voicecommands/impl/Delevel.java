package jf.gameserver.handler.voicecommands.impl;

import jf.gameserver.Config;
import jf.gameserver.handler.voicecommands.IVoicedCommandHandler;
import jf.gameserver.instancemanager.HellboundManager;
import jf.gameserver.model.base.Experience;
import jf.gameserver.model.Player;
import jf.gameserver.scripts.Functions;
import jf.gameserver.network.l2.components.CustomMessage;

public class Delevel extends Functions implements IVoicedCommandHandler
{
	private final String[] _commandList = new String[] { "delevel" };

	@Override
	public String[] getVoicedCommandList()
	{
		return _commandList;
	}

	@Override
	public boolean useVoicedCommand(String command, Player activeChar, String target)
	{
		if(!Config.ALLOW_VOICED_COMMANDS)
			return false;
		if(command.equals("delevel"))
		{
			int _old_level = activeChar.getLevel();
			if(_old_level == 1)
				return false;
			Long exp_add = Experience.LEVEL[_old_level-1] - activeChar.getExp();
			activeChar.addExpAndSp(exp_add, 0);
		}
		return false;
	}
}
