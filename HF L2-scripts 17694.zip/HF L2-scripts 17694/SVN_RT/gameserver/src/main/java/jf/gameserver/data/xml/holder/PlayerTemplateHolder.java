package jf.gameserver.data.xml.holder;

import jf.commons.data.xml.AbstractHolder;
import jf.gameserver.model.base.ClassId;
import jf.gameserver.model.base.ClassType;
import jf.gameserver.model.base.Race;
import jf.gameserver.model.base.Sex;
import jf.gameserver.templates.player.PlayerTemplate;

import org.napile.primitive.maps.IntObjectMap;
import org.napile.primitive.maps.impl.HashIntObjectMap;

/**
 * @author jfort
**/
public final class PlayerTemplateHolder extends AbstractHolder
{
	private static final PlayerTemplateHolder _instance = new PlayerTemplateHolder();

	private final IntObjectMap<PlayerTemplate> _templates = new HashIntObjectMap<PlayerTemplate>();

	public static PlayerTemplateHolder getInstance()
	{
		return _instance;
	}

	public void addPlayerTemplate(Race race, ClassType type, Sex sex, PlayerTemplate template)
	{
		_templates.put(makeHashCode(race, type, sex), template);
	}

	public PlayerTemplate getPlayerTemplate(ClassId classId, Sex sex)
	{
		return _templates.get(makeHashCode(classId.getRace(), classId.getType(), sex));
	}

	private static int makeHashCode(Race race, ClassType type, Sex sex)
	{
		return (race.ordinal() * 100000) + (type.getMainType().ordinal() * 1000) + (sex.ordinal() * 10);
	}

	@Override
	public int size()
	{
		return _templates.size();
	}

	@Override
	public void clear()
	{
		_templates.clear();
	}
}
