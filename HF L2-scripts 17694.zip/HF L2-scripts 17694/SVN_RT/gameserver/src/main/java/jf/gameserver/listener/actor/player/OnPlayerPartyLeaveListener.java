package jf.gameserver.listener.actor.player;

import jf.gameserver.listener.PlayerListener;
import jf.gameserver.model.Player;

public interface OnPlayerPartyLeaveListener extends PlayerListener
{
	public void onPartyLeave(Player player);
}
