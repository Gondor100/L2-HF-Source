package jf.gameserver.handler.voicecommands.impl;

import jf.gameserver.handler.voicecommands.IVoicedCommandHandler;
import jf.gameserver.model.Player;
import jf.gameserver.model.entity.CCPHelpers.CCPSmallCommands;
import jf.gameserver.scripts.Functions;

public class Online2 extends Functions implements IVoicedCommandHandler
{
	private static final String[] COMMANDS = { "online" };
	
	@Override
	public boolean useVoicedCommand(String command, Player activeChar, String target)
	{
		String answer = CCPSmallCommands.showOnlineCount();
		if (answer != null)
			activeChar.sendMessage(answer);
		return true;
	}
  
	@Override
	public String[] getVoicedCommandList()
	{
		return COMMANDS;
	}
}
