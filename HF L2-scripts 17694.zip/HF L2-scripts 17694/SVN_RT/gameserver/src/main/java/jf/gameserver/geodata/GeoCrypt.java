package jf.gameserver.geodata;

import java.io.IOException;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

/**
 * @author jfort
*/
public class GeoCrypt
{
	public static int decrypt(int blobOff, FileChannel roChannel, ByteBuffer buff) throws IOException
	{
		return 0;
	}
}