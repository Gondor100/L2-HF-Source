package jf.gameserver.handler.voicecommands.impl;

import jf.gameserver.handler.voicecommands.IVoicedCommandHandler;
import jf.gameserver.model.Player;
import jf.gameserver.model.entity.CCPHelpers.CCPSmallCommands;
import jf.gameserver.scripts.Functions;

public class Atod extends Functions implements IVoicedCommandHandler
{
	private static final String[] COMMANDS = new String[0];
  
	@Override
	public boolean useVoicedCommand(String command, Player activeChar, String params)
	{
		if (command.equalsIgnoreCase("openatod"))
		{
			if (params == null)
			{
				activeChar.sendMessage("Usage: .openatod <num>");
			}
			else
			{
				int num = 0;
				try
				{
					num = Integer.parseInt(params);
				}
				catch (NumberFormatException nfe)
				{
					activeChar.sendMessage("You must enter a number. Usage: .openatod <num>");
					return false;
				}
        
				CCPSmallCommands.openToad(activeChar, num);
			}
		}
    
		return true;
	}
  
	@Override
	public String[] getVoicedCommandList()
	{
		return COMMANDS;
	}
}
