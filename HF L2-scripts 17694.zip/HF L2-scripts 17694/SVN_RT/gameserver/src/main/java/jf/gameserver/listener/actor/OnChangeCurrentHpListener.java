package jf.gameserver.listener.actor;

import jf.gameserver.listener.CharListener;
import jf.gameserver.model.Creature;

/**
 * @author jfort
**/
public interface OnChangeCurrentHpListener extends CharListener
{
	public void onChangeCurrentHp(Creature actor, double oldHp, double newHp);
}