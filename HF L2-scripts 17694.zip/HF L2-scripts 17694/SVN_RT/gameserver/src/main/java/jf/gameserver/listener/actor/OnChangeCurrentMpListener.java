package jf.gameserver.listener.actor;

import jf.gameserver.listener.CharListener;
import jf.gameserver.model.Creature;

/**
 * @author jfort
**/
public interface OnChangeCurrentMpListener extends CharListener
{
	public void onChangeCurrentMp(Creature actor, double oldMp, double newMp);
}