package jf.gameserver.listener.actor;

import jf.gameserver.listener.CharListener;
import jf.gameserver.model.Creature;

public interface OnAttackListener extends CharListener
{
	public void onAttack(Creature actor, Creature target);
}
