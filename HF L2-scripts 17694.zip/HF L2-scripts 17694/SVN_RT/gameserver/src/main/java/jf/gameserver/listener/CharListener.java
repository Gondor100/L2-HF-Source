package jf.gameserver.listener;

import jf.commons.listener.Listener;
import jf.gameserver.model.Creature;

public interface CharListener extends Listener<Creature>
{

}
