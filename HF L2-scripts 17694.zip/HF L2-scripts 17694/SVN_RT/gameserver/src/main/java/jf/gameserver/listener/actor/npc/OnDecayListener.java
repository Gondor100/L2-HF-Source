package jf.gameserver.listener.actor.npc;

import jf.gameserver.listener.NpcListener;
import jf.gameserver.model.instances.NpcInstance;

public interface OnDecayListener extends NpcListener
{
	public void onDecay(NpcInstance actor);
}
