package jf.gameserver.handler.voicecommands.impl;

import jf.gameserver.handler.voicecommands.IVoicedCommandHandler;
import jf.gameserver.model.Player;
import jf.gameserver.model.entity.CCPHelpers.CCPCWHPrivilages;
import jf.gameserver.scripts.Functions;

public class CWHPrivileges2 extends Functions implements IVoicedCommandHandler
{
	private static final String[] _commandList = { "clan" };

	@Override	
	public boolean useVoicedCommand(String command, Player activeChar, String args)
	{
		CCPCWHPrivilages.clanMain(activeChar, args);
		return false;
	}
  
	@Override
	public String[] getVoicedCommandList()
	{
		return _commandList;
	}
}
