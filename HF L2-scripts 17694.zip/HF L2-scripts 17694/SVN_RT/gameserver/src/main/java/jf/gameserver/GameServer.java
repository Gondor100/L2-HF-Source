package jf.gameserver;

import gnu.trove.set.TIntSet;
import gnu.trove.set.hash.TIntHashSet;
import jf.commons.lang.StatsUtils;
import jf.commons.listener.Listener;
import jf.commons.listener.ListenerList;
import jf.commons.net.nio.impl.SelectorStats;
import jf.commons.net.nio.impl.SelectorThread;
import jf.commons.versioning.Version;
import jf.gameserver.cache.CrestCache;
import jf.gameserver.cache.ImagesCache;
import jf.gameserver.config.templates.HostInfo;
import jf.gameserver.config.xml.ConfigParsers;
import jf.gameserver.config.xml.holder.HostsConfigHolder;
import jf.gameserver.dao.CHeroDao;
import jf.gameserver.dao.CharacterDAO;
import jf.gameserver.dao.HidenItemsDAO;
import jf.gameserver.dao.ItemsDAO;
import jf.gameserver.data.BoatHolder;
import jf.gameserver.data.xml.Parsers;
import jf.gameserver.data.xml.holder.EventHolder;
import jf.gameserver.data.xml.holder.ResidenceHolder;
import jf.gameserver.data.xml.holder.StaticObjectHolder;
import jf.gameserver.database.DatabaseFactory;
import jf.gameserver.geodata.GeoEngine;
import jf.gameserver.handler.admincommands.AdminCommandHandler;
import jf.gameserver.handler.items.ItemHandler;
import jf.gameserver.handler.usercommands.UserCommandHandler;
import jf.gameserver.handler.voicecommands.VoicedCommandHandler;
import jf.gameserver.idfactory.IdFactory;
import jf.gameserver.instancemanager.*;
import jf.gameserver.instancemanager.games.FishingChampionShipManager;
import jf.gameserver.instancemanager.games.LotteryManager;
import jf.gameserver.instancemanager.games.MiniGameScoreManager;
import jf.gameserver.instancemanager.itemauction.ItemAuctionManager;
import jf.gameserver.instancemanager.naia.NaiaCoreManager;
import jf.gameserver.instancemanager.naia.NaiaTowerManager;
import jf.gameserver.instancemanager.DragonValleyManager;
import jf.gameserver.listener.GameListener;
import jf.gameserver.listener.game.OnShutdownListener;
import jf.gameserver.listener.game.OnStartListener;
import jf.gameserver.model.World;
import jf.gameserver.model.entity.Hero;
import jf.gameserver.model.entity.MonsterRace;
import jf.gameserver.model.entity.SevenSigns;
import jf.gameserver.model.entity.SevenSignsFestival.SevenSignsFestival;
import jf.gameserver.model.entity.events.fightclubmanager.FightClubEventManager;
import jf.gameserver.model.entity.olympiad.Olympiad;
import jf.gameserver.network.authcomm.AuthServerCommunication;
import jf.gameserver.network.l2.GameClient;
import jf.gameserver.network.l2.GamePacketHandler;
import jf.gameserver.network.telnet.TelnetServer;
import jf.gameserver.scripts.Scripts;
import jf.gameserver.security.HWIDBan;
import jf.gameserver.tables.*;
import jf.gameserver.taskmanager.ItemsAutoDestroy;
import jf.gameserver.taskmanager.TaskManager;
import jf.gameserver.taskmanager.tasks.RestoreOfflineTraders;
import jf.gameserver.utils.Strings;
import jf.gameserver.utils.Util;
import net.sf.ehcache.CacheManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.util.ArrayList;
import java.util.List;

public class GameServer
{
	public static boolean DEVELOP = false;

	public static final String CLIENT = "DEV";
	public static final String PROJECT_REVISION = "175";
	public static final String UPDATE_NAME = "High Five: Part 5";

	public static final int AUTH_SERVER_PROTOCOL = 2;
	private static final Logger _log = LoggerFactory.getLogger(GameServer.class);

	public class GameServerListenerList extends ListenerList<GameServer>
	{
		public void onStart()
		{
			for(Listener<GameServer> listener : getListeners())
				if(OnStartListener.class.isInstance(listener))
					((OnStartListener) listener).onStart();
		}

		public void onShutdown()
		{
			for(Listener<GameServer> listener : getListeners())
				if(OnShutdownListener.class.isInstance(listener))
					((OnShutdownListener) listener).onShutdown();
		}
	}

	public static GameServer _instance;

	private final List<SelectorThread<GameClient>> _selectorThreads = new ArrayList<SelectorThread<GameClient>>();
	private final SelectorStats _selectorStats = new SelectorStats();
	private Version version;
	private TelnetServer statusServer;
	private final GameServerListenerList _listeners;
	
	private int _serverStarted;

	private long _serverStartTimeMillis;

	private final int _onlineLimit;

	public List<SelectorThread<GameClient>> getSelectorThreads()
	{
		return _selectorThreads;
	}

	public SelectorStats getSelectorStats()
	{
		return _selectorStats;
	}

	public long getServerStartTime()
	{
		return _serverStartTimeMillis;
	}

	public int getOnlineLimit()
	{
		return _onlineLimit;
	}
	
	public int time()
	{
		return (int) (System.currentTimeMillis() / 1000);
	}
	
	public GameServer() throws Exception
	{
		_instance = this;
		_serverStartTimeMillis = System.currentTimeMillis();
		_serverStarted = time();
		_listeners = new GameServerListenerList();
		new File("./log/").mkdir();
		new File("./log/chars").mkdir();
		version = new Version(GameServer.class);
                                
		_log.info("[]==============[L2]==============================>");
		_log.info("License: ................ " + CLIENT);
		_log.info("Project Rev: ............ " + PROJECT_REVISION);
		_log.info("Game: ................... " + UPDATE_NAME);
		_log.info("Build date: ............. " + version.getBuildDate());
		_log.info("Compiler version: ....... " + version.getBuildJdk());
		_log.info("[]==============[L2]============================>");
		_log.info("[]==============[System]==========================>");
		_log.info(" " + Util.getOSInfo());
        _log.info(" " + Util.getCpuInfo()[0]);
        _log.info(" " + Util.getCpuInfo()[1]);
		_log.info(" " + Util.getJavaInfo());
		_log.info("[]==============[System]==========================>");	
		ConfigParsers.parseAll();
		Config.load();		
		_log.info("[]==============[Loading...]======================>");		
		 
		final TIntSet ports = new TIntHashSet();
		for(HostInfo host : HostsConfigHolder.getInstance().getGameServerHosts())
		{
			if(host.getIP() != null || host.getInnerIP() != null)
				ports.add(host.getPort());
		}

		_onlineLimit = Config.MAXIMUM_ONLINE_USERS;

		// Check binding address
		checkFreePorts(ports);

		// Initialize database
		Class.forName(Config.DATABASE_DRIVER).newInstance();
		DatabaseFactory.getInstance().getConnection().close();

		IdFactory _idFactory = IdFactory.getInstance();
		if(!_idFactory.isInitialized())
		{
			_log.error("Could not read object IDs from DB. Please Check Your Data.");
			throw new Exception("Could not initialize the ID factory");
		}

		CacheManager.getInstance();

		ThreadPoolManager.getInstance();
		
		//LfcDAO.LoadArenas();
		//LfcStatisticDAO.LoadGlobalStatistics();
		//LfcStatisticDAO.LoadLocalStatistics();

		BotCheckManager.loadBotQuestions();

		HidenItemsDAO.LoadAllHiddenItems();

		CHeroDao.LoadAllCustomHeroes();

		HWIDBan.LoadAllHWID();

		Scripts.getInstance();

		GeoEngine.load();

		Strings.reload();

		GameTimeController.getInstance();

		World.init();

		Parsers.parseAll();

		ItemsDAO.getInstance();

		CrestCache.getInstance();

		ImagesCache.getInstance();

		CharacterDAO.getInstance();

		ClanTable.getInstance();

		SkillTreeTable.getInstance();

		EnchantHPBonusTable.getInstance();

		PetSkillsTable.getInstance();

		ItemAuctionManager.getInstance();
		
		DragonValleyManager.getInstance();

		SpawnManager.getInstance().spawnAll();
		
		BoatHolder.getInstance().spawnAll();

		StaticObjectHolder.getInstance().spawnAll();

		RaidBossSpawnManager.getInstance();

		Scripts.getInstance().init();
		

		DimensionalRiftManager.getInstance();

		Announcements.getInstance();

		LotteryManager.getInstance();

		PlayerMessageStack.getInstance();

		if(Config.AUTODESTROY_ITEM_AFTER > 0)
			ItemsAutoDestroy.getInstance();

		MonsterRace.getInstance();

		SevenSigns.getInstance();
		SevenSignsFestival.getInstance();
		SevenSigns.getInstance().updateFestivalScore();

		AutoSpawnManager.getInstance();

		SevenSigns.getInstance().spawnSevenSignsNPC();

		if(Config.ENABLE_OLYMPIAD)
		{
			Olympiad.load();
			Hero.getInstance();
		}

		PetitionManager.getInstance();

		CursedWeaponsManager.getInstance();

		if(Config.ALLOW_WEDDING)
		{
			CoupleManager.getInstance();
			_log.info("CoupleManager initialized");
		}

		ItemHandler.getInstance();

		AdminCommandHandler.getInstance().log();
		UserCommandHandler.getInstance().log();
		VoicedCommandHandler.getInstance().log();

		TaskManager.getInstance();

		ClanTable.getInstance().checkClans();

		_log.info("<=[Events]========================================>");
		ResidenceHolder.getInstance().callInit();
		EventHolder.getInstance().callInit();
		_log.info("<=================================================>");

		CastleManorManager.getInstance();

		Runtime.getRuntime().addShutdownHook(Shutdown.getInstance());

		_log.info("IdFactory: Free ObjectID's remaining: " + IdFactory.getInstance().size());

		CoupleManager.getInstance();

		if(Config.ALT_FISH_CHAMPIONSHIP_ENABLED)
			FishingChampionShipManager.getInstance();
		_log.info("<=[Hellbound]=====================================>");

		HellboundManager.getInstance();

		NaiaTowerManager.getInstance();
		NaiaCoreManager.getInstance();

		SoDManager.getInstance();
		SoIManager.getInstance();
		BloodAltarManager.getInstance();
	
		MiniGameScoreManager.getInstance();

		if(Config.ALLOW_AWAY_STATUS)
			AwayManager.getInstance();	
	
		UnderGroundColliseumManager.getInstance();
		MMOTopManager.getInstance();
		L2TopManager.getInstance();
		if(Config.BUFF_STORE_ENABLED)
			OfflineBuffersTable.getInstance().restoreOfflineBuffers();

		Shutdown.getInstance().schedule(Config.RESTART_AT_TIME, Shutdown.RESTART);

		_log.info("GameServer Started");
		_log.info("Maximum Numbers of Connected Players: " + getOnlineLimit());

		FightClubEventManager.getInstance();

		registerSelectorThreads(ports);

		getListeners().onStart();

		if(Config.SERVICES_OFFLINE_TRADE_RESTORE_AFTER_RESTART)
			ThreadPoolManager.getInstance().schedule(new RestoreOfflineTraders(), 30000L);

		FakePlayersTable.getInstance();

		AuthServerCommunication.getInstance().start();

		if(Config.IS_TELNET_ENABLED)
			statusServer = new TelnetServer();
		else
			_log.info("Telnet server is currently disabled.");

		_log.info("<=================================================>");
		_log.info("Server Loaded in " + (System.currentTimeMillis() / 1000 - _serverStarted) + " seconds");
		String memUsage = new StringBuilder().append(StatsUtils.getMemUsage()).toString();
		for(String line : memUsage.split("\n"))
		_log.info(line);
		_log.info("<=================================================>");
	}
	
	public GameServerListenerList getListeners()
	{
		return _listeners;
	}

	public static GameServer getInstance()
	{
		return _instance;
	}

	public <T extends GameListener> boolean addListener(T listener)
	{
		return _listeners.add(listener);
	}

	public <T extends GameListener> boolean removeListener(T listener)
	{
		return _listeners.remove(listener);
	}

	private void checkFreePorts(TIntSet ports)
	{
		for(int port : ports.toArray())
		{
			while(!checkFreePort(null, port));
		}
	}

	private boolean checkFreePort(String ip, int port)
	{
		try
		{
			ServerSocket ss;
			if(ip == null)
				ss = new ServerSocket(port);
			else
				ss = new ServerSocket(port, 50, InetAddress.getByName(ip));
			ss.close();
		}
		catch(Exception e)
		{
			_log.warn("Port " + port + " is allready binded. Please free it and restart server.");
			try
			{
				Thread.sleep(1000L);
			}
			catch(InterruptedException e2)
			{
				//
			}
			return false;
		}
		return true;
	}

	private void registerSelectorThreads(TIntSet ports)
	{
		final GamePacketHandler gph = new GamePacketHandler();

		for(int port : ports.toArray())
			registerSelectorThread(gph, null, port);
	}

	private void registerSelectorThread(GamePacketHandler gph, String ip, int port)
	{
		try
		{
			SelectorThread<GameClient> selectorThread = new SelectorThread<GameClient>(Config.SELECTOR_CONFIG, _selectorStats, gph, gph, gph, null);
			selectorThread.openServerSocket(ip == null ? null : InetAddress.getByName(ip), port);
			selectorThread.start();
			_selectorThreads.add(selectorThread);
		}
		catch(Exception e)
		{
			//
		}
	}

	public static void main(String[] args) throws Exception
	{
		for(String arg : args)
		{
			if(arg.equalsIgnoreCase("-dev"))
				DEVELOP = true;
		}
		new GameServer();
	}

	public Version getVersion()
	{
		return version;
	}

	public TelnetServer getStatusServer()
	{
		return statusServer;
	}
}