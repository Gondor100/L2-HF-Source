package jf.gameserver.listener.actor;

import jf.gameserver.listener.CharListener;
import jf.gameserver.model.Creature;

/**
 * @author jfort
**/
public interface OnChangeCurrentCpListener extends CharListener
{
	public void onChangeCurrentCp(Creature actor, double oldCp, double newCp);
}