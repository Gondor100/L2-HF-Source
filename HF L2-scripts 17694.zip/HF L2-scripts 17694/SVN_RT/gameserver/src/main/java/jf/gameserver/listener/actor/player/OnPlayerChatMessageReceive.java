package jf.gameserver.listener.actor.player;

import jf.gameserver.listener.PlayerListener;
import jf.gameserver.model.Player;
import jf.gameserver.network.l2.components.ChatType;

/**
 * @author jfort
**/
public interface OnPlayerChatMessageReceive extends PlayerListener
{
	public void onChatMessageReceive(Player player, ChatType type, String charName, String text);
}
