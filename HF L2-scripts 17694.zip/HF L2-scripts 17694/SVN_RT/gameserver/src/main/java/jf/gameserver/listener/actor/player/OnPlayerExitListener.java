package jf.gameserver.listener.actor.player;

import jf.gameserver.listener.PlayerListener;
import jf.gameserver.model.Player;

public interface OnPlayerExitListener extends PlayerListener
{
	public void onPlayerExit(Player player);
}
