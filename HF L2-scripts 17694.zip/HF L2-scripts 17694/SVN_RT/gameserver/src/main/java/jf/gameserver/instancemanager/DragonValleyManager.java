package jf.gameserver.instancemanager;

import jf.commons.threading.RunnableImpl;
import jf.commons.util.Rnd;
import jf.gameserver.Config;
import jf.gameserver.ThreadPoolManager;
import jf.gameserver.model.GameObjectsStorage;
import jf.gameserver.model.Player;
import jf.gameserver.network.l2.s2c.Earthquake;
import jf.gameserver.network.l2.s2c.L2GameServerPacket;
import jf.gameserver.utils.Location;
import jf.gameserver.utils.MapUtils;

/**
 * @author Urban 
 * @date 2:07:53 25 июл. 2017 г.
 */
public class DragonValleyManager
{
	private static DragonValleyManager _instance;
	private static final long spawnDelay = Config.DRAGON_MIGRATION_PERIOD * 60 * 1000L;
	private static final int spawnShance = Config.DRAGON_MIGRATION_CHANCE;
	private static final String[] migrationGroups = { "migration1", "migration2", "migration3", "migration4" };
	private boolean wasSpawned = false;
	
	public static DragonValleyManager getInstance()
	{
		if(_instance == null)
			_instance = new DragonValleyManager();
		return _instance;
	}
	
	public DragonValleyManager()
	{
		manageSpawns();
	}
	
	private void manageSpawns()
	{
		if(!Config.DRAGONMAGMA_MIGRATE)
			return;
		
		for(String migrationGroup : migrationGroups)
			SpawnManager.getInstance().despawn(migrationGroup);
		
		ThreadPoolManager.getInstance().scheduleAtFixedRate(new RunnableImpl()
		{
			public void runImpl() throws Exception
			{
				if(Rnd.chance(spawnShance))
				{
					if(wasSpawned)
						for(String migrationGroup : migrationGroups)
							SpawnManager.getInstance().despawn(migrationGroup);
					
					for(String migrationGroup : migrationGroups)
					{
						SpawnManager.getInstance().spawn(migrationGroup);
						if(!wasSpawned)
							wasSpawned = true;
					}
					
					Location loc = new Location(101400, 117064, -3696);
					L2GameServerPacket eq = new Earthquake(loc, 30, 12);
					
					int rx = MapUtils.regionX(loc.getX());
					int ry = MapUtils.regionY(loc.getY());
					for(Player player : GameObjectsStorage.getAllPlayersForIterate())
					{
						if(player.getReflection() != ReflectionManager.DEFAULT)
							continue;
						
						int tx = MapUtils.regionX(player);
						int ty = MapUtils.regionY(player);
						
						if(tx >= rx && tx <= rx && ty >= ry && ty <= ry)
							player.sendPacket(eq);
					}
				}
			}
		}, spawnDelay, spawnDelay);
	}
}
