package jf.gameserver.handler.voicecommands.impl;

import jf.gameserver.handler.voicecommands.IVoicedCommandHandler;
import jf.gameserver.model.Player;
import jf.gameserver.model.entity.CCPHelpers.CCPSmallCommands;
import jf.gameserver.scripts.Functions;

public class CombineTalismans2 extends Functions implements IVoicedCommandHandler
{
	private static final String[] COMMANDS = { "combinetalismans" };
	
	@Override
	public boolean useVoicedCommand(String command, Player activeChar, String args)
	{
		CCPSmallCommands.combineTalismans(activeChar);
		return true;
	}
	
	@Override
	public String[] getVoicedCommandList()
	{
		return COMMANDS;
	}
}
