package jf.gameserver.listener.actor.npc;

import jf.gameserver.listener.NpcListener;
import jf.gameserver.model.instances.NpcInstance;

/**
 * @author PaInKiLlEr
 */
public interface OnShowChatListener extends NpcListener
{
	public void onShowChat(NpcInstance actor);
}