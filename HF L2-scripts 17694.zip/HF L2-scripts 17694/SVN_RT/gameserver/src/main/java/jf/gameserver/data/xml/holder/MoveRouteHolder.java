package jf.gameserver.data.xml.holder;

import java.util.HashMap;
import java.util.Map;
import jf.commons.data.xml.AbstractHolder;
import jf.gameserver.templates.moveroute.MoveRoute;

/**
 * @author Urban 
 * @date 2:54:02 25 июл. 2017 г.
 */

public class MoveRouteHolder extends AbstractHolder
{
  private static MoveRouteHolder _instance = new MoveRouteHolder();
  private Map<String, MoveRoute> _routes = new HashMap<String, MoveRoute>();
  
  public static MoveRouteHolder getInstance(){
    return _instance;
  }
  
  public void addRoute(MoveRoute route){
    _routes.put(route.getName(), route);
  }
  
  public MoveRoute getRoute(String name){
    return _routes.get(name);
  }
  
  @Override
  public int size(){
    return _routes.size();
  }
  
  @Override
  public void clear(){
    _routes.clear();
  }
}
