package jf.gameserver.listener.actor.player;

import jf.gameserver.listener.PlayerListener;
import jf.gameserver.model.Player;

/**
 * @author : Ragnarok
 * @date : 28.03.12  16:54
 */
public interface OnLevelChangeListener extends PlayerListener
{
	public void onLevelChange(Player player, int oldLvl, int newLvl);
}
