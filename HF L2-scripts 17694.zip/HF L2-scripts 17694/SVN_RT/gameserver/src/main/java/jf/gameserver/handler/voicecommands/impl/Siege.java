package jf.gameserver.handler.voicecommands.impl;

import jf.gameserver.data.xml.holder.ResidenceHolder;
import jf.gameserver.handler.voicecommands.IVoicedCommandHandler;
import jf.gameserver.model.Player;
import jf.gameserver.model.entity.residence.Castle;
import jf.gameserver.network.l2.s2c.CastleSiegeInfo;
import jf.gameserver.network.l2.s2c.NpcHtmlMessage;

public class Siege implements IVoicedCommandHandler
{
	@Override
	public boolean useVoicedCommand(String command, Player activeChar, String target)
	{
		if(!target.isEmpty())
		{
			int castleId = Integer.parseInt(target);
			Castle castle = (Castle)ResidenceHolder.getInstance().getResidence(castleId);
			activeChar.sendPacket(new CastleSiegeInfo(castle, activeChar));
		}
		showMainPage(activeChar);
		return true;
	}
	
	private static void showMainPage(Player activeChar)
	{
		activeChar.sendPacket(new NpcHtmlMessage(0).setFile("command/siege.htm"));
	}
  
	@Override
	public String[] getVoicedCommandList()
	{
		return new String[] { "siege" };
	}
}
