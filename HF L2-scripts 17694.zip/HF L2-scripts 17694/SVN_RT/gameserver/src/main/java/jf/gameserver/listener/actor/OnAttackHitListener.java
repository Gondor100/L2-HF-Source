package jf.gameserver.listener.actor;

import jf.gameserver.listener.CharListener;
import jf.gameserver.model.Creature;

public interface OnAttackHitListener extends CharListener
{
	public void onAttackHit(Creature actor, Creature attacker);
}
