package jf.gameserver.listener.actor.player;

import jf.gameserver.listener.PlayerListener;
import jf.gameserver.model.Player;
import jf.gameserver.model.entity.Reflection;

public interface OnTeleportListener extends PlayerListener
{
	public void onTeleport(Player player, int x, int y, int z, Reflection reflection);
}
