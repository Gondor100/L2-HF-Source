package jf.gameserver.ai;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.ScheduledFuture;

import jf.commons.util.Rnd;
import jf.gameserver.Config;
import jf.gameserver.ThreadPoolManager;
import jf.gameserver.data.xml.holder.FakePlayersHolder;
import jf.gameserver.dao.CharacterDAO;
import jf.gameserver.dao.OlympiadNobleDAO;
import jf.gameserver.dao.OlympiadHistoryDAO;
import jf.gameserver.geodata.GeoEngine;
import jf.gameserver.listener.actor.OnDeathListener;
import jf.gameserver.listener.actor.player.OnLevelChangeListener;
import jf.gameserver.listener.actor.player.OnPlayerChatMessageReceive;
import jf.gameserver.listener.actor.player.OnTeleportListener;
import jf.gameserver.model.Creature;
import jf.gameserver.model.Effect;
import jf.gameserver.model.EffectList;
import jf.gameserver.model.GameObject;
import jf.gameserver.model.Player;
import jf.gameserver.model.Skill;
import jf.gameserver.model.Territory;
import jf.gameserver.model.World;
import jf.gameserver.model.Zone;
import jf.gameserver.model.base.Race;
import jf.gameserver.model.base.RestartType;
import jf.gameserver.model.entity.Reflection;
import jf.gameserver.model.instances.NpcInstance;
import jf.gameserver.model.instances.TreasureChestInstance;
import jf.gameserver.model.items.ItemInstance;
import jf.gameserver.network.l2.components.ChatType;
import jf.gameserver.skills.EffectType;
import jf.gameserver.skills.effects.EffectTemplate;
import jf.gameserver.tables.FakePlayersTable;
import jf.gameserver.templates.ZoneTemplate;
import jf.gameserver.templates.fakeplayer.FakePlayerAITemplate;
import jf.gameserver.templates.fakeplayer.FarmZoneTemplate;
import jf.gameserver.templates.fakeplayer.TownZoneTemplate;
import jf.gameserver.templates.fakeplayer.actions.*;
import jf.gameserver.utils.FakePlayerUtils;
import jf.gameserver.utils.ItemFunctions;
import jf.gameserver.utils.Location;
import jf.gameserver.utils.PositionUtils;
import jf.gameserver.utils.TeleportUtils;

import org.napile.primitive.sets.IntSet;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static jf.gameserver.ai.CtrlIntention.AI_INTENTION_ACTIVE;
import static jf.gameserver.ai.CtrlIntention.AI_INTENTION_ATTACK;
import static jf.gameserver.ai.CtrlIntention.AI_INTENTION_PICK_UP;

/**
 * @author jfort
**/
public class FakeAI extends PlayerAI implements OnDeathListener, OnLevelChangeListener, OnTeleportListener, OnPlayerChatMessageReceive
{
	private class DistanceComparator implements Comparator<GameObject>
	{
		@Override
		public int compare(GameObject o1, GameObject o2)
		{
			Player player = getActor();
			if(player != null)
				return (int) (o1.getDistance(player) - o2.getDistance(player));
			return 0;
		}
	}

	private static final Logger _log = LoggerFactory.getLogger(FakeAI.class);

	private static final int MAX_ACTION_TRY_COUNT = 500;
	private static final int CHECK_INVENTORY_DELAY = 900000; // 15 минут.
	private static final int SEARCH_PVP_PK_DELAY = 60000; // 1 минута.
	private static final int ATTACK_WAIT_DELAY = 180000; // 3 минуты.
	private static final int SHOUT_CHAT_MIN_DELAY = 60000; // 1 минута.
	private static final int SHOUT_CHAT_MAX_DELAY = 600000; // 10 минут.

	private final FakePlayerAITemplate _aiTemplate;

	private final DistanceComparator _distanceComparator = new DistanceComparator();

	private ScheduledFuture<?> _actionTask;

	private final List<AbstractAction> _plannedActions = new ArrayList<AbstractAction>();
	private AbstractAction _lastPerformedAction = null;
	private int _lastActionTryCount = 0;

	private FarmZoneTemplate _currentFarmZone = null;

	private long _waitEndTime = 0L;
	private long _goToTownTime = -1L;
	private long _lastCheckInventoryTime = 0L;
	private long _lastSearchPvPPKTime = 0L;
	private long _lastAttackTime = 0L;
	private long _nextShoutChatTime = 0L;

	public FakeAI(Player player, FakePlayerAITemplate aiTemplate)
	{
		super(player);
		_aiTemplate = aiTemplate;
	}

	@Override
	protected void onEvtSpawn()
	{
		super.onEvtSpawn();

		Player actor = getActor();

		actor.addListener(this);

		if(actor.entering)
		{
			if(actor.getOnlineTime() == 0)
				planActions(_aiTemplate.getOnCreateAction());
		}

		actor.setActive();

		startActionTask();
	}

	@Override
	public void onEvtDeSpawn()
	{
		getActor().removeListener(this);
		stopActionTask();
		super.onEvtDeSpawn();
	}

	@Override
	public boolean isFake()
	{
		return true;
	}

	public void startWait(int minDelay, int maxDelay)
	{
		_waitEndTime = System.currentTimeMillis() + Rnd.get(minDelay, maxDelay);
	}

	public void stopWait()
	{
		_waitEndTime = 0;
	}

	private boolean isWait()
	{
		return _waitEndTime > System.currentTimeMillis() || getIntention() == AI_INTENTION_PICK_UP;
	}

	private boolean planActions(OrdinaryActions action)
	{
		if(action == null)
			return false;

		List<AbstractAction> actions = makeActionsList(action.makeActionsList());
		if(actions.isEmpty())
			return false;

		clearPlannedActions();

		// TODO: Проверку на количество действий
		_plannedActions.addAll(actions);
		return true;
	}

	private List<AbstractAction> makeActionsList(List<AbstractAction> actions)
	{
		if(actions.isEmpty())
			return Collections.emptyList();

		List<AbstractAction> actionsList = new ArrayList<AbstractAction>();
		for(AbstractAction action : actions)
		{
			double chance = action.getChance();
			if(chance <= 0 || chance >= 100 || Rnd.chance(chance))
			{
				List<AbstractAction> tempList = action.makeActionsList();
				if(tempList == null)
					actionsList.add(action);
				else
					actionsList.addAll(makeActionsList(tempList));
			}
		}
		return actionsList;
	}

	private void clearPlannedActions()
	{
		_plannedActions.clear();
		_lastPerformedAction = null;
		_lastActionTryCount = 0;
	}

	private void clearCurrentFarmZone()
	{
		getActor().setTarget(null);
		_currentFarmZone = null;
		_goToTownTime = -1L;
	}

	private boolean performNextAction(boolean force)
	{
		synchronized(this)
		{
			if(_nextShoutChatTime < System.currentTimeMillis())
			{
				FakePlayerUtils.writeToShoutChat(this);
				_nextShoutChatTime = System.currentTimeMillis() + Rnd.get(SHOUT_CHAT_MIN_DELAY, SHOUT_CHAT_MAX_DELAY);
			}

			if(isWait())
				return false;

			Player player = getActor();

			if(!player.isAlikeDead())
			{
				int dropCount = 0;
				ItemInstance dropItem = null;
				for(GameObject object : World.getAroundObjects(player, 2000, 1000))
				{
					if(object instanceof ItemInstance)
					{
						ItemInstance item = (ItemInstance) object;
						if(item.getItemId() != 8190 && item.getItemId() != 8689) // Не подымаем проклятое оружие.
						{
							if(player.getDistance(item) > 10000 || !GeoEngine.canMoveToCoord(player.getX(), player.getY(), player.getZ(), item.getX(), item.getY(), item.getZ(), player.getGeoIndex()))
								continue;

							if(ItemFunctions.checkIfCanPickup(player, item))
							{
								if(dropItem == null || player.getDistance(item) < player.getDistance(dropItem))
									dropItem = item;
								dropCount++;
							}
						}
					}
				}

				GameObject target = player.getTarget();
				if(target != null && (target instanceof Creature))
				{
					Creature creatureTarget = (Creature) target;
					boolean attackable = creatureTarget.isAutoAttackable(player);

					Player targetPlayer = creatureTarget.getPlayer();
					if(targetPlayer != null)
						attackable = targetPlayer.isCtrlAttackable(player, (targetPlayer.isPK() || targetPlayer.getPvpFlag() > 0), false);

					if(!attackable || creatureTarget.isAlikeDead() || !creatureTarget.isVisible() || creatureTarget.isInvisible() || player.getDistance(creatureTarget) > 10000 || !GeoEngine.canMoveToCoord(player.getX(), player.getY(), player.getZ(), creatureTarget.getX(), creatureTarget.getY(), creatureTarget.getZ(), player.getGeoIndex()))
					{
						player.setTarget(null);
						player.abortAttack(true, false);
						player.abortCast(true, false);
						startWait(100, dropCount == 0 ? 2000 : 700);
						return true;
					}
					else if(player.getAI().getAttackTarget() != creatureTarget && player.getAI().getCastTarget() != creatureTarget || getIntention() != AI_INTENTION_ATTACK)
					{
						attack(creatureTarget);
						return true;
					}
				}

				if(_plannedActions.isEmpty() && getIntention() == AI_INTENTION_ACTIVE || Rnd.chance(5))
				{
					if(dropItem != null && !player.isMoving && !player.isMovementDisabled())
					{
						dropItem.onAction(player, false);
						startWait(500, dropCount == 1 ? 3000 : 1000);
						return true;
					}

					if((_lastSearchPvPPKTime + SEARCH_PVP_PK_DELAY) < System.currentTimeMillis())
					{
						for(Creature pk : player.getAroundCharacters(1000, 250))
						{
							if(pk.isPlayer())
							{
								Player targetPlayer = pk.getPlayer();
								if(!targetPlayer.isAlikeDead() && targetPlayer.isVisible() && !targetPlayer.isInvisible() && player.getDistance(targetPlayer) <= 10000 && GeoEngine.canMoveToCoord(player.getX(), player.getY(), player.getZ(), pk.getX(), pk.getY(), pk.getZ(), player.getGeoIndex()))
								{
									boolean attackable = targetPlayer.isCtrlAttackable(player, false, false);
									if(attackable)
									{
										if(Rnd.chance(5))
										{
											player.setTarget(targetPlayer);
											startWait(1000, 3000);
											return true;
										}
									}
									else
									{
										attackable = targetPlayer.isCtrlAttackable(player, true, false);
										if(attackable)
										{
											if(Rnd.chance(1))
											{
												player.setTarget(targetPlayer);
												startWait(1000, 3000);
												return true;
											}
										}
									}
								}
							}
						}
						_lastSearchPvPPKTime = System.currentTimeMillis();
					}
				}

				if((_lastCheckInventoryTime + CHECK_INVENTORY_DELAY) < System.currentTimeMillis())
				{
					if(FakePlayerUtils.checkInventory(this))
					{
						startWait(200, 5000);
						return true;
					}

					// TODO: Переделать.
					if(player.getClassId().isOfRace(Race.ORC) || !player.isMageClass())
						_plannedActions.add(new UseCommunityAction("_cbbsbuffer get 0 1_0 Warrior;Воину", 100));
					else
						_plannedActions.add(new UseCommunityAction("_cbbsbuffer get 0 1_0 Mystic;Магу", 100));

					_lastCheckInventoryTime = System.currentTimeMillis();
				}
			}

			if(!_plannedActions.isEmpty())
			{
				AbstractAction action = _plannedActions.get(0);

				_lastActionTryCount++;
				if(_lastActionTryCount <= MAX_ACTION_TRY_COUNT) // Заглушка, чтобы боты не зависали.
				{
					if(!action.checkCondition(this, force))
						return false;

					if(!action.performAction(this))
						return false;
				}
				else
					_lastActionTryCount = 0;

				_plannedActions.remove(action);
				_lastPerformedAction = action;
			}
			else if(player.isDead())
			{
				clearPlannedActions();
				clearCurrentFarmZone();

				_plannedActions.add(new ReviveAction());
			}
			else if(_currentFarmZone != null)
			{
				farm();
			}
			else
			{
				Location closestTownLoc = TeleportUtils.getRestartLocation(player, RestartType.TO_VILLAGE);

				TownZoneTemplate townZone = null;
				for(TownZoneTemplate t : FakePlayersHolder.getInstance().getTownZones())
				{
					Territory territory = t.getZoneTemplate().getTerritory();
					if(territory.isInside(closestTownLoc.x, closestTownLoc.y, closestTownLoc.z))
					{
						townZone = t;
						break;
					}
				}

				if(townZone != null)
				{
					Territory territory = townZone.getZoneTemplate().getTerritory();
					if(territory.isInside(player.getX(), player.getY(), player.getZ()))
					{
						planActions(townZone.getActions());
						return true;
					}
				}

				FarmZoneTemplate farmZone = null;
				for(FarmZoneTemplate f : _aiTemplate.getFarmZones())
				{
					Territory territory = f.getZoneTemplate().getTerritory();
					if(territory.isInside(player.getX(), player.getY(), player.getZ()))
					{
						farmZone = f;
						break;
					}
				}

				if(farmZone != null)
				{
					if(!farmZone.checkCondition(player))
					{
						if(player.getLevel() >= farmZone.getMaxLevel())
						{
							OrdinaryActions actions = farmZone.getOnObtainMaxLevelAction();
							if(actions != null)
								planActions(actions);
						}
						else
						{
							// TODO: Сделать список глобальных действий и вынести в датапак.
							_plannedActions.add(new TeleportToClosestTownAction(100));
						}
					}
					else
					{
						_currentFarmZone = farmZone;
						return performFarm();
					}
				}
				else
				{
					if(townZone == null)
					{
						List<FarmZoneTemplate> availableFarmZones = new ArrayList<FarmZoneTemplate>();
						for(FarmZoneTemplate f : _aiTemplate.getFarmZones())
						{
							if(f.checkCondition(player))
								availableFarmZones.add(f);
						}

						farmZone = Rnd.get(availableFarmZones);
						if(farmZone == null)
							return false;

						_currentFarmZone = farmZone;
						return performFarm();
					}
					else
					{
						// TODO: Сделать список глобальных действий и вынести в датапак.
						_plannedActions.add(new TeleportToClosestTownAction(100));
					}
				}
			}
			return true;
		}
	}

	public boolean performFarm()
	{
		Player player = getActor();

		if(_currentFarmZone == null)
		{
			List<FarmZoneTemplate> availableFarmZones = new ArrayList<FarmZoneTemplate>();
			for(FarmZoneTemplate f : _aiTemplate.getFarmZones()) // Выбираем подходящие зоны, в которых уже находимся.
			{
				if(!f.checkCondition(player))
					continue;

				Territory territory = f.getZoneTemplate().getTerritory();
				if(!territory.isInside(player.getX(), player.getY(), player.getZ()))
					continue;

				availableFarmZones.add(f);
			}

			if(availableFarmZones.isEmpty())
			{
				for(FarmZoneTemplate f : _aiTemplate.getFarmZones())
				{
					if(f.checkCondition(player))
						availableFarmZones.add(f);
				}
			}

			FarmZoneTemplate farmZone = Rnd.get(availableFarmZones);
			if(farmZone == null)
			{
				_log.warn("Cannot find farm zone from player RACE[" + player.getRace() + "], TYPE[" + player.getClassId().getType() + "], CLASS[" + player.getClassId() + "], LEVEL[" + player.getLevel() + "]!");
				return false;
			}

			_currentFarmZone = farmZone;
			_lastAttackTime = System.currentTimeMillis();
		}

		clearPlannedActions();
		return true;
	}

	private void farm()
	{
		if(isWait())
			return;

		Player player = getActor();

		if(player.isMoving || player.isMovementDisabled())
			return;

		if(!_currentFarmZone.checkCondition(player))
		{
			if(player.getLevel() >= _currentFarmZone.getMaxLevel())
			{
				OrdinaryActions actions = _currentFarmZone.getOnObtainMaxLevelAction();
				if(actions != null)
					planActions(actions);
			}
			clearCurrentFarmZone();
			return;
		}

		GoToTownActions goToTownActions = _currentFarmZone.getGoToTownActions();
		if(goToTownActions != null)
		{
			if(_goToTownTime == -1L)
			{
				_goToTownTime = System.currentTimeMillis() + (Rnd.get(goToTownActions.getMinFarmTime(), goToTownActions.getMaxFarmTime()) * 1000L);
			}
			else if(_goToTownTime < System.currentTimeMillis())
			{
				planActions(goToTownActions);
				clearCurrentFarmZone();
				return;
			}
		}

		ZoneTemplate zoneTemplate = _currentFarmZone.getZoneTemplate();
		Reflection reflection = player.getReflection();
		Zone zone = reflection.getZone(zoneTemplate.getName());
		if(zone == null)
		{
			zone = new Zone(zoneTemplate);
			zone.setReflection(reflection);
			zone.setActive(true);
			reflection.addZone(zone);
		}

		List<NpcInstance> npcs = getNpcsForAttack(zone.getInsideNpcs());
		Collections.sort(npcs, _distanceComparator);

		for(NpcInstance npc : npcs)
		{
			if(prepareAttack(npc))
				return;
		}

		List<NpcInstance> arroundNpcs = getNpcsForAttack(player.getAroundNpc(2000, 1000));
		Collections.sort(arroundNpcs, _distanceComparator);

		for(NpcInstance npc : arroundNpcs)
		{
			if(prepareAttack(npc))
				return;
		}

		NpcInstance npc = npcs.isEmpty() ? null : npcs.get(0);

		Territory territory = zoneTemplate.getTerritory();
		if((_lastAttackTime + ATTACK_WAIT_DELAY) < System.currentTimeMillis())
		{
			_lastAttackTime = System.currentTimeMillis();

			Location loc = npc != null ? npc.getLoc() : territory.getRandomLoc(player.getGeoIndex());
			player.teleToLocation(loc, 0, 0);
			return;
		}

		if(npc != null || !territory.isInside(player.getX(), player.getY(), player.getZ()))
		{
			Location loc = npc != null ? npc.getLoc() : territory.getRandomLoc(player.getGeoIndex());
			if(player.getDistance(loc) > 10000 || !player.moveToLocation(Location.findAroundPosition(loc, 0, player.getGeoIndex()), 0, true, 50))
			{
				Location restartLoc = null;
				if(player.isPK())
				{
					restartLoc = Rnd.get(zoneTemplate.getPKRestartPoints());
					if(!territory.isInside(restartLoc.x, restartLoc.y, restartLoc.z))
					{
						// TODO: Придумать алгоритм поиска ближайшей точки зоны к заданой точке и измерять дистанцию от нее.
						if(PositionUtils.calculateDistance(restartLoc.x, restartLoc.y, loc.x, loc.y) > 10000)
						{
							//_log.warn("PK restart point for farm zone \"" + zoneTemplate.getName() + "\" is long away!");
							restartLoc = null;
						}
					}
				}
				if(restartLoc == null)
				{
					restartLoc = Rnd.get(zoneTemplate.getRestartPoints());
					if(!territory.isInside(restartLoc.x, restartLoc.y, restartLoc.z))
					{
						// TODO: Придумать алгоритм поиска ближайшей точки зоны к заданой точке и измерять дистанцию от нее.
						if(PositionUtils.calculateDistance(restartLoc.x, restartLoc.y, loc.x, loc.y) > 10000)
						{
							//_log.warn("PK restart point for farm zone \"" + zoneTemplate.getName() + "\" is long away!");
							restartLoc = null;
						}
					}
				}
				if(restartLoc == null)
					restartLoc = loc;
				if(player.isInRange(restartLoc, 50))
					restartLoc = loc;
				if(!player.isInRange(restartLoc, 50))
				{
					if(player.getDistance(restartLoc) > 10000 || !player.moveToLocation(Location.findAroundPosition(restartLoc, 50, 150, player.getGeoIndex()), 0, true, 50))
						player.teleToLocation(restartLoc, 0, 0);
					return;
				}
			}
			else
				return;
		}

		Location loc = Location.coordsRandomize(player.getLoc(), 100, 300);
		if(territory.isInside(loc.x, loc.y, loc.z) && player.moveToLocation(Location.findAroundPosition(loc, 0, player.getGeoIndex()), 0, true, 50))
			startWait(1000, 10000);
	}

	private List<NpcInstance> getNpcsForAttack(List<NpcInstance> avaialbleNpcs)
	{
		Player player = getActor();

		List<NpcInstance> npcs = new ArrayList<NpcInstance>();
		for(NpcInstance n : avaialbleNpcs)
		{
			if(n.isAlikeDead())
				continue;

			if(n.isInvul())
				continue;

			if(!n.isVisible())
				continue;

			if(n.isInvisible())
				continue;

			if(_currentFarmZone.isIgnoredMonster(n.getNpcId()))
				continue;

			IntSet farmMonsters = _currentFarmZone.getFarmMonsters();
			if(farmMonsters.isEmpty())
			{
				if(Math.abs(player.getLevel() - n.getLevel()) > 10)
					continue;
			}
			else if(!farmMonsters.contains(n.getNpcId()))
				continue;

			if(!n.isMonster() || n.isRaid() || (n instanceof TreasureChestInstance))
				continue;

			if(n.getAI().getAttackTarget() != null && n.getAI().getAttackTarget() != player ||  n.getAI().getCastTarget() != null && n.getAI().getCastTarget() != player)
			{
				if(Rnd.chance(95))
					continue;
			}

			npcs.add(n);
		}
		return npcs;
	}

	private boolean prepareAttack(Creature target)
	{
		Player player = getActor();

		if(player.getDistance(target) <= 10000 && GeoEngine.canMoveToCoord(player.getX(), player.getY(), player.getZ(), target.getX(), target.getY(), target.getZ(), player.getGeoIndex()))
		{
			if(Rnd.chance(20))
			{
				player.setCurrentHp(player.getMaxHp(), true, true);
				player.setCurrentMp(player.getMaxMp());
			}

			if(Rnd.chance(15) && (player.getClassId().isOfRace(Race.ORC) || !player.isMageClass()))
			{
				player.moveToLocation(Location.findAroundPosition(target, 80, 180), 0, true, 50);
				player.setTarget(target);
				startWait(500, 3000);
				return true;
			}

			_lastAttackTime = System.currentTimeMillis();

			player.setTarget(target);
			startWait(1000, 3000);
			return true;
		}
		return false;
	}

	private void attack(Creature target)
	{
		Player player = getActor();
		/*if(Rnd.chance(1))
		{
			player.setTarget(null);
			player.abortAttack(true, false);
			player.abortCast(true, false);
			player.moveToLocation(Location.findAroundPosition(player.getLoc(), 500, 1000, player.getGeoIndex()), 250, true);
			return;
		}*/

		if(Rnd.chance(80))
		{
			if(tryRunOff(target))
				return;
		}

		if(Rnd.chance(5))
		{
			Skill skill = getRandomSkillSelf();
			if(skill != null)
			{
				Cast(skill, player);
				return;
			}
		}

		if(!GeoEngine.canSeeTarget(player, target, false))
		{
			if(!player.isMoving)
			{
				if(!player.moveToLocation(Location.findAroundPosition(target, 50, 150), 0, true, 50))
					player.setTarget(null);
				return;
			}
		}

		Skill skill = getRandomSkill(player, target);
		if(skill == null && player.isMageClass() && !player.getClassId().isOfRace(Race.ORC) && Rnd.chance(90))
			return;

		if(skill != null)
		{
			if(Rnd.chance(30))
			{
				Cast(skill, target, false, false);
				return;
			}
		}

		if(player.getClassId().isOfRace(Race.ORC) || !player.isMageClass())
			Attack(target, true, false);
	}

	private boolean tryRunOff(Creature target)
	{
		if(target.isAlikeDead())
			return false;

		Player player = getActor();
		if(player.getPhysicalAttackRange() > 100 || (!player.getClassId().isOfRace(Race.ORC) && player.isMageClass()))
		{
			if(player.getDistance(target) <= 200 && !player.isMoving)
			{
				int posX = player.getX();
				int posY = player.getY();
				int posZ = player.getZ();

				int old_posX = posX;
				int old_posY = posY;
				int old_posZ = posZ;

				int signx = posX < target.getX() ? -1 : 1;
				int signy = posY < target.getY() ? -1 : 1;

				int range = Math.max((int) (player.getPhysicalAttackRange() * 0.9), 400);

				posX += signx * range;
				posY += signy * range;
				posZ = GeoEngine.getHeight(posX, posY, posZ, player.getGeoIndex());

				if(GeoEngine.canMoveToCoord(old_posX, old_posY, old_posZ, posX, posY, posZ, player.getGeoIndex()))
				{
					player.abortAttack(true, false);
					if(player.moveToLocation(Location.findAroundPosition(posX, posY, posZ, 0, 0, player.getGeoIndex()), 0, true))
						return true;
				}
			}
		}
		return false;
	}

	private Skill getRandomSkillSelf()
	{
		List<Skill> skills = new ArrayList<>();
		loop: for(Skill skill : getActor().getAllSkills())
		{
			if(!skill.isActive() && !skill.isToggle())
				continue;

			if(skill.hasEffect(EffectType.Transformation))
				continue;

			if(getActor().isSkillDisabled(skill))
				continue;

			if(skill.getSkillType() == Skill.SkillType.BUFF)
			{
				for(Effect e : getActor().getEffectList().getAllEffects())
				{
					if(checkEffect(e, skill))
						continue loop;
				}

				switch(skill.getTargetType())
				{
					case TARGET_ONE:
					case TARGET_SELF:
						skills.add(skill);
						break;
				}
			}
		}
		return skills.isEmpty() ? null : skills.get(Rnd.get(skills.size()));
	}

	/**
	 * Возвращает true если эффект для скилла уже есть и заново накладывать не надо
	 */
	private boolean checkEffect(Effect ef, Skill skill)
	{
		if(ef == null)
			return false;

		if(ef.getPeriod() <= 0)
			return true;

		EffectTemplate[] effectTemplates = skill.getEffectTemplates();
		if(effectTemplates.length == 0)
			return false;

		EffectTemplate effectTemplate = effectTemplates[0];
		if(!EffectList.checkStackType(ef.getTemplate(), effectTemplate)) // такого скилла нет
			return false;
		if(ef.getStackOrder() < effectTemplate._stackOrder) // старый слабее
			return false;
		if(ef.getTimeLeft() > 10) // старый не слабее и еще не кончается - ждем
			return true;
		if(ef.getNext() != null) // старый не слабее но уже кончается - проверить рекурсией что там зашедулено
			return checkEffect(ef.getNext(), skill);
		return false;
	}


	private Skill getRandomSkill(Player player, Creature target)
	{
		List<Skill> weakSkills = new ArrayList<>();
		List<Skill> skills = new ArrayList<>();
		for(Skill skill : player.getAllSkills())
		{
			if(!skill.isActive())
				continue;

			/*switch(skill.getId())
			{
				case 11030:
				case 30546:
				case 30547:
					continue;
			}*/

			if(player.isSkillDisabled(skill))
				continue;

			if(!skill.checkCondition(player, target, false, false, true))
				continue;

			double chance = 0;

			switch(skill.getSkillType())
			{
				case DEBUFF:
				case PARALYZE:
				case ROOT:
				case STEAL_BUFF:
				case DOT:
				case AIEFFECTS:
				case CPDAM:
				case DELETE_HATE:
				case MDOT:
				case DECOY:
				case AGGRESSION:
				case CHARGE:
				case POISON:
				case SLEEP:
				case CHARGE_SOUL:
				case DESTROY_SUMMON:
				case SHIFT_AGGRESSION:
				case DISCORD:
				case MANADAM:
				case MUTE:
					chance = 5.;
					break;
				case DRAIN:
					chance = (5. + ((100. - getActor().getCurrentCpPercents()) / 5.)) / (player.isMageClass() ? 1. : 3.);
					break;
				case MDAM:
					chance = !player.getClassId().isOfRace(Race.ORC) && player.isMageClass() ? 100 : 5;
					break;
				case PDAM:
				case STUN:
				case LETHAL_SHOT:
					chance = 15.;
					break;
			}

			switch(skill.getTargetType())
			{
				case TARGET_AURA:
				case TARGET_AREA:
				case TARGET_MULTIFACE:
				case TARGET_MULTIFACE_AURA:
					chance /= 10.;
					break;
			}

			if(Rnd.chance(chance))
			{
				if(skill.getMagicLevel() < (player.getLevel() - 10))
					weakSkills.add(skill);
				else
					skills.add(skill);
			}
		}

		if(skills.isEmpty())
			skills = weakSkills;

		return Rnd.get(skills);
	}

	@Override
	protected void onEvtAttacked(Creature attacker, int damage)
	{
		synchronized(this)
		{
			if(Rnd.chance(60))
			{
				if(tryRunOff(attacker))
					return;
			}

			if(damage > 0)
			{
				if(isWait())
					startWait(100, 500);

				Player player = getActor();
				if(attacker.isNpc())
				{
					if(Rnd.chance(25))
					{
						player.setCurrentHp(player.getCurrentHp() + (player.getMaxHp() / 5), true, true);
						player.setCurrentMp(player.getCurrentMp() + (player.getMaxMp() / 5));
					}
				}

				double chance = 25;

				GameObject target = player.getTarget();
				if(target != null)
				{
					if(target == attacker)
						return;

					if(target instanceof Creature)
					{
						Creature creatureTarget = (Creature) target;
						if(creatureTarget.getAI().getAttackTarget() != player && creatureTarget.getAI().getCastTarget() != player)
							chance = 80;
						else
							chance = 5;
					}
					else
						return;
				}

				if(attacker.isPlayable())
					chance = 30;

				if((attacker.getLevel() - player.getLevel()) >= 10)
					chance = 5;

				if(Rnd.chance(chance))
				{
					player.setTarget(attacker);
					stopWait();
				}
			}
		}
	}

	@Override
	public void onDeath(Creature actor, Creature killer)
	{
		synchronized(this)
		{
			startWait(2000, 15000);
			clearPlannedActions();
			clearCurrentFarmZone();

			_plannedActions.add(new ReviveAction());
		}
	}

	@Override
	public void onLevelChange(Player player, int oldLvl, int newLvl)
	{
		synchronized(this)
		{
			if(player.isFakePlayer())
			{
				FakePlayerUtils.setProf(player);
			}
			/*if(player.getLevel() == Config.ALT_MAX_LEVEL) // TODO: Переделать.
			{
				int objectId = player.getObjectId();

				player.kick();
				
				CharacterDAO.getInstance().deleteCharByObjId(objectId);

				// Remove character from olympiad nobles
				OlympiadNobleDAO.getInstance().delete(objectId);

				// Clear history for this character
				OlympiadHistoryDAO.getInstance().clearHistory(objectId);

				FakePlayersTable.spawnNewFakePlayer();
			}*/
		}
	}

	@Override
	public void onTeleport(Player player, int x, int y, int z, Reflection reflection)
	{
		synchronized(this)
		{
			startWait(2000, 5000);
		}
	}

	@Override
	public void onChatMessageReceive(Player player, ChatType type, String charName, String text)
	{
		if(type == ChatType.TELL)
			FakePlayerUtils.writeInPrivateChat(this, charName);
	}

	@Override
	public void runImpl() throws Exception
	{
		Player actor = getActor();
		if(actor == null)
		{
			stopActionTask();
			return;
		}
		performNextAction(false);
	}

	private synchronized void startActionTask()
	{
		if(_actionTask == null)
			_actionTask = ThreadPoolManager.getInstance().scheduleAtFixedDelay(this, 500L, 500L);
	}

	private synchronized void stopActionTask()
	{
		if(_actionTask != null)
		{
			_actionTask.cancel(true);
			_actionTask = null;
		}
	}
}