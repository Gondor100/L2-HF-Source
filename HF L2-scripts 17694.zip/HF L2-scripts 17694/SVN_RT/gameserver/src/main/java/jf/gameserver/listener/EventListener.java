package jf.gameserver.listener;

import jf.commons.listener.Listener;
import jf.gameserver.model.entity.events.GlobalEvent;

/**
 * @author VISTALL
 * @date 7:17/10.06.2011
 */
public interface EventListener extends Listener<GlobalEvent>
{

}
