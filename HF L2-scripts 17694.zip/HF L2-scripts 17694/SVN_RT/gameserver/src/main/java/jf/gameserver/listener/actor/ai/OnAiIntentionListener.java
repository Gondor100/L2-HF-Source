package jf.gameserver.listener.actor.ai;

import jf.gameserver.ai.CtrlIntention;
import jf.gameserver.listener.AiListener;
import jf.gameserver.model.Creature;

public interface OnAiIntentionListener extends AiListener
{
	public void onAiIntention(Creature actor, CtrlIntention intention, Object arg0, Object arg1);
}
