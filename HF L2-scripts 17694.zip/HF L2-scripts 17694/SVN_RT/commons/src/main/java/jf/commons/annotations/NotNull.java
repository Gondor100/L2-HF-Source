package jf.commons.annotations;

/**
 * Null Value is NOT Handled.
 */
public @interface NotNull {}
