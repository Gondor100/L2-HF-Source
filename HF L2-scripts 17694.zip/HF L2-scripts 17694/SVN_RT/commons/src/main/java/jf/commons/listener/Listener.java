package jf.commons.listener;

public interface Listener<T>
{

}
