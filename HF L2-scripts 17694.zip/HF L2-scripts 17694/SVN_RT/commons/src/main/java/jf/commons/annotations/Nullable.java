package jf.commons.annotations;

/**
 * Null Value is Handled.
 */
public @interface Nullable {}
