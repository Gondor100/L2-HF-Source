package jf.authserver.network.gamecomm.as2gs;

import jf.authserver.Config;
import jf.authserver.network.gamecomm.GameServer;
import jf.authserver.network.gamecomm.GameServer.HostInfo;
import jf.authserver.network.gamecomm.SendablePacket;

/**
 * @reworked by jfort
**/
public class AuthResponse extends SendablePacket
{
	private HostInfo[] _hosts;

	public AuthResponse(GameServer gs)
	{
		_hosts = gs.getHosts();
	}

	@Override
	protected void writeImpl()
	{
		writeC(0x00);
		writeC(0x00); // ServerId
		writeS(""); // ServerName
		writeC(_hosts.length);
		for(HostInfo host : _hosts)
		{
			writeC(host.getId());
			writeS(Config.SERVER_NAMES.get(host.getId()));
		}
	}
}