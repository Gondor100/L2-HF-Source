package jf.authserver.network.gamecomm.gs2as;

import jf.authserver.network.gamecomm.GameServer;
import jf.authserver.network.gamecomm.ReceivablePacket;

public class PlayerLogout extends ReceivablePacket
{
	private String account;

	@Override
	protected void readImpl()
	{
		account = readS();
	}

	@Override
	protected void runImpl()
	{
		GameServer gs = getGameServer();
		if(gs.isAuthed())
			gs.removeAccount(account);
	}
}
